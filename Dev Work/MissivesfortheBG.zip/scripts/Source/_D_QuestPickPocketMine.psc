;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 1
Scriptname _D_QuestPickPocketMine Extends Quest Hidden

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Mine
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Mine Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Target1
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Target1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY NearestFence
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_NearestFence Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Minemarker1
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MineMarker Auto
;END ALIAS PROPERTY

Import PO3_Events_Form

;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE

KilledForeman.SetValue(0)
UpdateCurrentInstanceGlobal(KilledForeman)
InJail.SetValue(0)
UpdateCurrentInstanceGlobal(InJail)


SetObjectiveDisplayed(20)
if(Game.GetPlayer().GetItemCount(Alias_Item.GetRef()))
SetObjectiveCompleted(20)
SetObjectiveDisplayed(40)
endIf
;END CODE
EndFunction
;END FRAGMENT


;BEGIN FRAGMENT Fragment_3
Function Fragment_3()
;BEGIN CODE
CompleteAllObjectives()

Bool Started = _m_StealQuest.Start()

LocationAlias  mineAlias    = _m_StealQuest.getAliasByName("Mine") as LocationAlias 
ReferenceAlias MineLocation = _m_StealQuest.getAliasByName("InnMarker1") as ReferenceAlias


MineLocation.ForceRefTo(Alias_MineMarker.GetRef()) 
mineAlias.ForceLocationTo(Alias_Mine.GetLocation()) 

_m_StealQuest.SetStage(20)

Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)
SetStage(110)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")

Alias_Item.GetRef().delete()
UnregisterForUpdate()
	
endIf

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_10
Function Fragment_10()
;BEGIN CODE
; Quest shutdown Stage 250 - PLAYER ARRESTED
	FailAllObjectives()
	
	if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
		Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Board")
	elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
		Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Player")
	else 
	Alias_Missive.GetRef().delete()
	endIf

	Alias_Item.GetRef().delete()
	UnregisterForUpdate()
	stop()
;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

Event OnQuestStageChange(Quest akQuest, Int aiNewStage)				; function from po3 papyrus extender.	; moved to quest script

	if aiNewStage == 40
		RegisterForUpdate(0.1)
	endif
EndEvent

Event OnUpdate()

	if GlobJail.Getvalue() == 1 
		InJail.SetValue(1)
		UpdateCurrentInstanceGlobal(InJail)
		GlobJail.SetValue(0)
		UpdateCurrentInstanceGlobal(GlobJail)
		FailAllObjectives()
		Setstage(250)
	endIf
endEvent


MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

Quest Property _m_StealQuest  Auto  

GlobalVariable Property KilledForeman  Auto  
GlobalVariable Property InJail         Auto  
GlobalVariable Property GlobJail     Auto  


