;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 11
Scriptname _D_QuestGatherDestScript Extends Quest Hidden

import PO3_SKSEFunctions	
import _D_MissivesUtils				

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker1
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker2
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker2 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Inn1
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Inn1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY OtherHold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_OtherHold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Inn2
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Inn2 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

Event OnInit()

	OrigName = m_Message.Getname()
	
	ItemTotal.SetValue(Utility.RandomInt(ItemTotalMin.GetValue() as int, ItemTotalMax.GetValue() as int))

	UpdateCurrentInstanceGlobal(ItemTotal)
	
	Book()
	
endEvent			  

Function Book()

	If OrigName ==  "" 
		OrigName = m_Message.Getname()
	endif

	if Alias_Missive != None && Alias_Item != None

		ObjectReference bookRef = Alias_Missive.GetReference()
		ObjectReference itemRef = Alias_Item.GetReference()
		Location destinationLoc = Alias_OtherHold.GetLocation()
		
		if bookRef != None && itemRef != None && destinationLoc != None
			UpdateBookTitleWithItemAndDestination(bookRef, itemRef, destinationLoc, m_Message as message, ItemTotal.GetValue() as int)
		endif

	endif

ENDFUNCTION		   
;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE

	Book()	   
	
	ItemCount.SetValue(Game.GetPlayer().GetItemCount(Alias_Item.GetRef().GetBaseObject()))

	UpdateCurrentInstanceGlobal(ItemCount)
		
	SetObjectiveDisplayed(20)

	if (ItemCount.GetValue() >= ItemTotal.GetValue())
		SetObjectiveCompleted(20)
		SetObjectiveDisplayed(40)
	endIf

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
CompleteAllObjectives()

int RewardValue = Alias_Item.GetRef().GetBaseObject().getGoldValue() * ItemTotal.GetValue() as int 

RewardValue = RewardValue + GoldReward.GetValue() as int

Game.GetPlayer().RemoveItem(Alias_Item.GetRef().GetBaseObject(), ItemTotal.GetValue() as int)
Game.GetPlayer().AddItem(Gold001, RewardValue)
Game.GetPlayer().AddItem(Reward)

SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

m_Message.Setname(OrigName)

while(Alias_QuestGiver.GetRef().Is3DLoaded())
Utility.Wait(1.0)
endWhile
Alias_QuestGiver.GetRef().Disable()

Stop()
;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

String OrigName

GlobalVariable Property ItemCount  Auto  

GlobalVariable Property ItemTotal  Auto  

GlobalVariable Property ItemTotalMax  Auto  

GlobalVariable Property ItemTotalMin  Auto  

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

LeveledItem Property Reward  Auto  

Message property m_Message Auto