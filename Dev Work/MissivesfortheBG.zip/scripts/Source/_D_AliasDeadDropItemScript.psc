scriptName _D_AliasDeadDropItemScript extends ReferenceAlias conditional

;-- Properties --------------------------------------

;-- Variables ---------------------------------------

;-- Functions ---------------------------------------

; Skipped compiler generated GetState

function OnActivate(objectreference akActionRef)

	if akActionRef == game.GetPlayer() as objectreference 
		if GetOwningQuest().GetStage() == 40
			(GetOwningQuest() as _D_QuestDeadDropScript).SetQuestComplete()
			debug.notification("The Dead Drop runes glow and clicks as the item disappears")
		endIf
	endIf
endFunction

