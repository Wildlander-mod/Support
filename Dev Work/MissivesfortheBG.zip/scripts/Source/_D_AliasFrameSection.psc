Scriptname _D_AliasFrameSection extends ReferenceAlias  

ReferenceAlias Property Alias_ItemContainer Auto
ReferenceAlias Property Alias_Item Auto


Event OnContainerChanged(ObjectReference newContainer, ObjectReference oldContainer)

	if(GetOwningQuest().GetStage() > 20)
		if(oldContainer == Game.GetPlayer() && !newContainer )	
			GetOwningQuest().Setstage(250) 
		elseif(oldContainer == Game.GetPlayer() && newContainer == Alias_ItemContainer.getref())
			GetOwningQuest().SetObjectiveDisplayed(40, true)
			GetOwningQuest().SetObjectiveCompleted(30)	
			GetOwningQuest().setstage(40)
		elseif(oldContainer == Game.GetPlayer())
			GetOwningQuest().SetObjectiveDisplayed(40, false)
			GetOwningQuest().SetObjectiveDisplayed(35, true, true)
		endIf
	endIf
	 
	if (GetOwningQuest().GetStage() == 40) 
		if (oldContainer == Alias_ItemContainer.getref() && newContainer == Game.GetPlayer()) 

			 Game.GetPlayer().RemoveItem(Alias_Item.GetRef(), 1, true, newContainer )
			 Debug.Notification("The item appears to have been enchanted and can't be removed from the container")
		endif 
	endif
EndEvent
