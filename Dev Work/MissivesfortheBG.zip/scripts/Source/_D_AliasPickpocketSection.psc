Scriptname _D_AliasPickpocketSection extends referencealias

Quest Property m_DarkPickpocketQuest  Auto  

Event OnContainerChanged(ObjectReference newContainer, ObjectReference oldContainer)

if (m_DarkPickpocketQuest.GetStage() == 20) 
 if (newContainer == Game.GetPlayer()) 
		m_DarkPickpocketQuest.SetObjectivecompleted(20)  
		m_DarkPickpocketQuest.setstage(25)
		m_DarkPickpocketQuest.SetObjectivedisplayed(25)
	endif 
endif

if (m_DarkPickpocketQuest.GetStage() == 25) 
 if (newContainer ==  target2.GetActorRef()) 
		m_DarkPickpocketQuest.SetObjectivecompleted(25)  
		m_DarkPickpocketQuest.setstage(30)
		m_DarkPickpocketQuest.SetObjectivedisplayed(30)
	endif 
endif

	
EndEvent	

ReferenceAlias Property Target2  Auto  
