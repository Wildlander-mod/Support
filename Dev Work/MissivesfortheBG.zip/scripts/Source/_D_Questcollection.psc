;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 10
Scriptname _D_QuestCollection Extends Quest Hidden

;BEGIN ALIAS PROPERTY Dealer
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Dealer Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY TargetLocation
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_TargetLocation Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY container1
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_container1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Skooma
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Skooma Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY container2
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_container2 Auto
;END ALIAS PROPERTY
;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY NearestFence
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_NearestFence Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY


;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE
SetObjectiveDisplayed(20)
if(Game.GetPlayer().GetItemCount(Alias_Skooma.GetRef()))
SetObjectiveCompleted(20)
SetObjectiveDisplayed(40)
endIf
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

if(Alias_Dealer.GetRef().GetItemCount(Alias_Skooma.GetRef()) > 0)
Alias_Dealer.GetRef().RemoveItem(Alias_Skooma.GetRef())


endIf

Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
	; Stage 105

	FailAllObjectives()
	SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE

if(Game.GetPlayer().GetItemCount(Alias_Skooma.GetRef())) == 0
	SetObjectiveDisplayed(40, false)
	SetObjectiveDisplayed(30, true, true)
endif

;END CODE
EndFunction
;END FRAGMENT


;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_3
Function Fragment_3()
;BEGIN CODE
CompleteAllObjectives()
Game.GetPlayer().RemoveItem(Alias_Skooma.GetRef())

int RewardValue = Alias_Skooma.GetRef().GetBaseObject().getGoldValue() * 2

Game.GetPlayer().RemoveItem(Alias_Skooma.GetRef().GetBaseObject())
Game.GetPlayer().AddItem(Gold001, RewardValue)

SetStage(110)
;END CODE
EndFunction
;END FRAGMENT


;END FRAGMENT CODE - Do not edit anything between this and the begin comment

MiscObject Property Gold001  Auto  


