;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 11
Scriptname _D_QuestGatherPotionDestScript Extends Quest Hidden
import PO3_SKSEFunctions
import _D_MissivesUtils
 
;BEGIN ALIAS PROPERTY NearestFence
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_NearestFence Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Potion
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Potion Auto
;END ALIAS PROPERTY		
				
;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY OtherHold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_OtherHold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Recipient
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY City
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_City Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Inn1
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Inn1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker1
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Inn2
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Inn2 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker2
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker2 Auto
;END ALIAS PROPERTY


;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
	
SetObjectiveDisplayed(20)
Actor player = Game.GetPlayer()

CheckInventoryforPotions(player)

Alias_QuestGiver.GetRef().Enable()

DeliveryDate.SetValue((GameDaysPassed.GetValue() + Duration.GetValue()) as int)
UpdateCurrentInstanceGlobal(DeliveryDate)


;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
	CompleteAllObjectives()

	int RewardValue = Alias_Potion.GetRef().GetBaseObject().getGoldValue() 

	RewardValue = RewardValue + GoldReward.GetValue() as int

	Game.GetPlayer().RemoveItem(Alias_Potion.GetRef().GetBaseObject())
	Game.GetPlayer().AddItem(Gold001, RewardValue)									   
	Game.GetPlayer().AddItem(Reward)
	
	If (Game.GetPlayer().GetCurrentLocation() != Alias_Inn1.GetLocation() && Game.GetPlayer().GetCurrentLocation() != Alias_Inn2.GetLocation() )
		Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)
	endif	

SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

while(Alias_QuestGiver.GetRef().Is3DLoaded())
	Utility.Wait(1.0)
endWhile

Alias_QuestGiver.GetRef().Disable()

Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_13
Function Fragment_13()

;BEGIN CODE

    ;Debug.Trace("Stage 5: Missive Setup - Select Poison")
	
	Maintenance()
	
;END CODE
EndFunction  
;END FRAGMENT


;BEGIN FRAGMENT Fragment_15
Function Fragment_15()
;BEGIN CODE

; Quest shutdown Stage 103 - Quest failed - Delivery not met.


	Alias_Item.GetRef().SetActorOwner(Alias_QuestGiver.GetActorRef().GetActorBase())

	int Bounty = GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue()

	SetBounty(Alias_QuestGiver.GetActorRef() as actor , Bounty)

	SetStage(105)

;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment


Function PotionAdded(potion Potionbase, Objectreference akItemReference)

	bool IsRequiredPotion
	bool notusedbycurrentquest 
	
	If GetStage() == 20 
	
		if IsObjectiveDisplayed(20)  && akItemReference.GetNumReferenceAliases() > 0 
			;Can't use this one is already attached to quest objectives
			notusedbycurrentquest = true
		endif

		if !notusedbycurrentquest 
			IsRequiredPotion = _m_MissivesUtils.isPotionofType( Potionbase,  PotionEffect )
				
			if IsRequiredPotion && !IsObjectiveDisplayed(40)
				SetObjectiveCompleted(20)
				SetObjectiveDisplayed(40, true, true)											
				Alias_Potion.ForceRefTo(akItemReference)
				_m_Global_AlchemyCount.setvalue(1)
				UpdateCurrentInstanceGlobal(_m_Global_AlchemyCount)									
			endIf
		ENDIF 
	
	endif

endFunction

Function PotionRemoved(potion Potionbase, ObjectReference akItemReference)

	if IsObjectiveDisplayed(40)	
		bool IsRequiredPotion

		IsRequiredPotion = _m_MissivesUtils.isPotionofType( Potionbase,  PotionEffect )
				
		if IsRequiredPotion && akItemReference == Alias_Potion.GetRef()
				 
			ObjectReference  Defaultpotion = Game.GetFormFromFile(0x9E4, "MissivesSharedResources.Esp") as ObjectReference 

			Alias_Potion.ForceRefTo(Defaultpotion)

			Potion baseObj = akItemReference.GetBaseObject() as potion
			
			if baseObj
				akItemReference.SetName(baseObj.GetName())
			endif
		
			SetObjectiveDisplayed(40, false)
			
			CheckInventoryforPotions(Game.GetPlayer())
		
			if !IsObjectiveDisplayed(40)	
				SetObjectiveCompleted(20, false)
				SetObjectiveDisplayed(20, true, true)
				_m_Global_AlchemyCount.setvalue(0)
				UpdateCurrentInstanceGlobal(_m_Global_AlchemyCount)

			endif
		endIf
	endif


endFunction

Function RecheckInventory(form itemToDrop)

	; Need to Drop & Pickup this to detect each potion - So we remove it , then add it back to player's inventory to trigger "on item added"
	If GetStage() == 20 
		Actor player = Game.GetPlayer()

		bool IsRequiredPotion = _m_MissivesUtils.isPotionofType(itemToDrop as Potion,  PotionEffect )

		if IsRequiredPotion
			DropAllOfItem(player, itemToDrop, QContainer, 1)
		endif
	endif 
EndFunction

function CheckInventoryforPotions(Actor player)

If GetStage() == 20 
	Form[] Forms = player.GetContainerForms() 
	Int L = Forms.Length 
	Int iIndex = 0 
	While iIndex < L 
		Form kItem = Forms[iIndex]
		if (kItem as Potion) 
			bool IsRequiredPotion = isPotionofType( kItem as Potion,  PotionEffect )
			
			if IsRequiredPotion
				RecheckInventory(kItem)
			endif
		endif

		iIndex += 1 
		
		if getstage() == 40 
			iIndex = L
		endif 
		
	EndWhile
endif 

endFunction

Function Maintenance()
    ; This code runs every time the game is loaded
	
	Potion ItemBase = Alias_Item.GetRef().GetBaseObject() as Potion

	PotionEffect = ItemBase.GetNthEffectMagicEffect(0)

	_m_ItemName.setName("Potion with the effect of " + PotionEffect.getname()) 
																						  
	String PotionName = PotionEffect.getname()
	int count = 1

	UpdateBookTitlePotion(count, PotionName, M_message, Alias_Otherhold)
 
EndFunction

Function SetBounty(Actor target, int amount) ;This function will increase the player's bounty for the specific region he is in by a specific amount 

	Game.IncrementStat("Items Stolen")
	
	Location EastmarchHoldLocation = Game.GetFormFromFile(0x01676A, "Skyrim.esm") as Location
	Location FalkreathHoldLocation = Game.GetFormFromFile(0x01676F, "Skyrim.esm") as Location
	Location HaafingarHoldLocation = Game.GetFormFromFile(0x016770, "Skyrim.esm") as Location
	Location HjaalmarchHoldLocation = Game.GetFormFromFile(0x01676E, "Skyrim.esm") as Location
	Location PaleHoldLocation = Game.GetFormFromFile(0x01676D, "Skyrim.esm") as Location
	Location ReachHoldLocation = Game.GetFormFromFile(0x016769, "Skyrim.esm") as Location
	Location RiftHoldLocation = Game.GetFormFromFile(0x01676C, "Skyrim.esm") as Location
	Location WhiterunHoldLocation = Game.GetFormFromFile(0x016772, "Skyrim.esm") as Location
	Location WinterholdHoldLocation = Game.GetFormFromFile(0x01676B, "Skyrim.esm") as Location
	Location DLC2SolstheimLocation = Game.GetFormFromFile(0x016E2A, "Dragonborn.esm") as Location

	Faction CrimeFactionEastmarch  = Game.GetFormFromFile(0x0267E3, "Skyrim.esm") as faction
	Faction CrimeFactionFalkreath  = Game.GetFormFromFile(0x028170, "Skyrim.esm") as faction
	Faction CrimeFactionHaafingar  = Game.GetFormFromFile(0x029DB0, "Skyrim.esm") as faction
	Faction CrimeFactionReach = Game.GetFormFromFile(0x02816C, "Skyrim.esm") as faction
	Faction CrimeFactionHjaalmarch = Game.GetFormFromFile(0x02816D, "Skyrim.esm") as faction
	Faction CrimeFactionPale = Game.GetFormFromFile(0x02816E, "Skyrim.esm") as faction
	Faction CrimeFactionRift = Game.GetFormFromFile(0x02816B, "Skyrim.esm") as faction
	Faction CrimeFactionWhiterun = Game.GetFormFromFile(0x0267EA, "Skyrim.esm") as faction
	Faction CrimeFactionWinterhold = Game.GetFormFromFile(0x02816F, "Skyrim.esm") as faction
	Faction CrimeFactionSolstheim = Game.GetFormFromFile(0x018279, "Dragonborn.esm") as faction
	
	Faction Currentlocation = CrimeFactionWhiterun as faction
 
	If target.IsInLocation(WhiterunHoldLocation)
		 Currentlocation = CrimeFactionWhiterun

	elseif target.IsInLocation(FalkreathHoldLocation)
		 Currentlocation = CrimeFactionFalkreath 
	elseif target.IsInLocation(EastmarchHoldLocation)
		 Currentlocation = CrimeFactionEastmarch 

	elseif target.IsInLocation(HaafingarHoldLocation)
		 Currentlocation = CrimeFactionHaafingar 

	elseif target.IsInLocation(ReachHoldLocation)
		 Currentlocation = CrimeFactionReach 

	elseif target.IsInLocation(HjaalmarchHoldLocation)
		 Currentlocation = CrimeFactionHjaalmarch 
 
	elseif target.IsInLocation(PaleHoldLocation)
		 Currentlocation = CrimeFactionPale
 
	elseif target.IsInLocation(RiftHoldLocation)
		 Currentlocation = CrimeFactionRift 
 
	elseif target.IsInLocation(WinterholdHoldLocation)
		 Currentlocation = CrimeFactionWinterhold 

	endif
	
	int OldCrimeGold = Currentlocation.GetCrimeGold() ;get bounty before we increase it

	Utility.Wait(0.10)
	Alias_Item.GetRef().SetActorOwner(target.GetActorBase())
	Currentlocation.ModCrimeGold(GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue())
	Game.IncrementStat("Items Stolen")

	int NewCrimeGold = Currentlocation.GetCrimeGold() ;get bounty after we increase it
	Debug.Notification((NewCrimeGold - OldCrimeGold) + " bounty from Failing Missive")

 
EndFunction



MagicEffect PotionEffect    

Message property _m_ItemName Auto

MiscObject Property Gold001  Auto  

GlobalVariable Property GameDaysPassed  Auto  

GlobalVariable Property DeliveryDate  Auto  

GlobalVariable Property duration  Auto  

GlobalVariable Property GoldReward  Auto  

GlobalVariable Property _m_Global_AlchemyCount   Auto  

LeveledItem Property Reward  Auto  

ObjectReference Property QContainer Auto

Message property m_Message Auto