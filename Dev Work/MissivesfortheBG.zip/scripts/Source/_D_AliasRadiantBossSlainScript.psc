scriptName _D_AliasRadiantBossSlainScript extends ReferenceAlias conditional

;-- Properties --------------------------------------
globalvariable property pTGRFailGlobal auto conditional

;-- Variables ---------------------------------------

;-- Functions ---------------------------------------

; Skipped compiler generated GotoState

; Skipped compiler generated GetState

function OnDeath(Actor akKiller)

	pTGRFailGlobal.value = 1 as Float
	self.GetOwningQuest().SetStage(250)
endFunction
