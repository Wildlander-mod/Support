Scriptname _D_AliasPlayerAlchemy extends ReferenceAlias  

ReferenceAlias Property ItemRef Auto
import _D_MissivesUtils

Event OnInit()
	if(ItemRef.GetRef())
		PO3_Events_Alias.RegisterForItemCrafted(self)
		RegisterForMenu("ContainerMenu")
		RegisterForMenu("BarterMenu")
		RegisterForMenu("Crafting Menu")							  
	endIf
endEvent

event OnMenuClose(String menuName)

	if((GetOwningQuest().getstage() > 10 && GetOwningQuest().IsObjectiveDisplayed(20)) && MenuName == "ContainerMenu" ) 
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _D_QuestGatherPotionDestScript).CheckInventoryforPotions(player)
		endif	
	endIf
	
	if((GetOwningQuest().getstage() > 10 && GetOwningQuest().IsObjectiveDisplayed(20)) && MenuName == "BarterMenu" ) 
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _D_QuestGatherPotionDestScript).CheckInventoryforPotions(player)
		endif	
	endIf
	
	if((GetOwningQuest().getstage() > 10 && GetOwningQuest().IsObjectiveDisplayed(20)) && MenuName == "Crafting Menu" ) 
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _D_QuestGatherPotionDestScript).CheckInventoryforPotions(player)
		endif	
	endIf
	
endEvent



Event OnItemAdded(Form akBaseItem, int aiItemCount, ObjectReference akItemReference, ObjectReference akSourceContainer)
	
	if (!akItemReference) && (akBaseItem as Potion) 
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _D_QuestGatherPotionDestScript).CheckInventoryforPotions(player)
		endif	
	elseif (akItemReference) && GetOwningQuest().getstage() > 10
		if(!GetOwningQuest().IsObjectiveDisplayed(40) && (akBaseItem as Potion) )	
			(GetOwningQuest() as _D_QuestGatherPotionDestScript).PotionAdded(akBaseItem as Potion, akItemReference as ObjectReference)
		endIf
	endif
endEvent


Event OnItemRemoved(Form akBaseItem, int aiItemCount, ObjectReference akItemReference, ObjectReference akDestContainer)

	if(GetOwningQuest().IsObjectiveDisplayed(40) && (akBaseItem as Potion) && akItemReference)
		(GetOwningQuest() as _D_QuestGatherPotionDestScript).PotionRemoved(akBaseItem as Potion, akItemReference as ObjectReference)
	endIf
	
endEvent

Event OnItemCrafted(ObjectReference akBench, Location akLocation, Form akCreatedItem)

	if (akCreatedItem as Potion) && GetOwningQuest().getstage() > 10
		if !GetOwningQuest().IsObjectiveDisplayed(40)
		
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _D_QuestGatherPotionDestScript).CheckInventoryforPotions(player)
		endif	
	endif

EndEvent

Function shutdownScript(Int currentVersion, Int nevVersion)
    UnregisterForAllMenus()
	PO3_Events_Alias.UnRegisterForItemCrafted(self)
EndFunction