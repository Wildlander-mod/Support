Scriptname _D_AliasMurderNoble extends ReferenceAlias  

bool Property MakeAggressiveAndAttackPlayerIfAttacked = true Auto
bool Property MakeAggressiveOnGainLOSToPlayer = true Auto
float Property MakeAggressiveOnDistanceToPlayer = 512.0 Auto
float Property MakeAggressiveLOSDistanceToPlayer = 600.0 Auto

ReferenceAlias property AliasToAnger auto

Event OnUpdate()

	if( GetReference() )
	
		if MakeAggressiveOnDistanceToPlayer > 0
		
			if GetReference().GetDistance(Game.GetPlayer()) < MakeAggressiveOnDistanceToPlayer
				;debug.trace(self + "OnUpdate() player is within MakeAggressiveOnDistanceToPlayer [ " + MakeAggressiveOnDistanceToPlayer + "], making aggressive to player.")
				(GetOwningQuest() as _D_QuestMurder).makeAliasAggressiveAndAttackPlayer(self)
				(GetOwningQuest() as _D_QuestMurder).makeAliasAggressiveAndAttackPlayer(AliasToAnger)
			Else
		
				;debug.trace(self + "OnUpdate() player isn't close enough, so calling RegisterForSingleUpdate(1) to poll again later.")
				RegisterForSingleUpdate(1)
			EndIf
		EndIf
	EndIf

EndEvent

Event OnHit(ObjectReference akAggressor, Form akSource, Projectile akProjectile, bool abPowerAttack, bool abSneakAttack, bool abBashAttack, bool abHitBlocked)

    if MakeAggressiveAndAttackPlayerIfAttacked && akAggressor == Game.GetPlayer()
        (GetOwningQuest() as _D_QuestMurder).makeAliasAggressiveAndAttackPlayer(self)
        (GetOwningQuest() as _D_QuestMurder).makeAliasAggressiveAndAttackPlayer(AliasToAnger)
    EndIf

EndEvent

Event OnGainLOS(Actor akViewer, ObjectReference akTarget)
    if akViewer == GetActorReference() && akTarget == Game.GetPlayer() as Actor

        float angle = akViewer.GetHeadingAngle(Game.GetPlayer())

        ; Only trigger if the player is in front of the actor
        ; -45 to +45 degrees = roughly a 90° vision cone
        if Math.Abs(angle) <= 45.0
            if GetReference().GetDistance(Game.GetPlayer()) < MakeAggressiveLOSDistanceToPlayer
                (GetOwningQuest() as _D_QuestMurder).makeAliasAggressiveAndAttackPlayer(self)
                (GetOwningQuest() as _D_QuestMurder).makeAliasAggressiveAndAttackPlayer(AliasToAnger)
            endif
        endif
    endif
EndEvent


Event OnDying(Actor akKiller)

    ; Only count if the player killed this actor
    if akKiller == Game.GetPlayer()

        ; Increment the player's murder stat
        Game.IncrementStat("Murders")

        ; If your quest needs to react to the murder, call your aggression logic
            (GetOwningQuest() as _D_QuestMurder).makeAliasAggressiveAndAttackPlayer(AliasToAnger)
    endif

EndEvent


Event OnLoad()

	if MakeAggressiveOnGainLOSToPlayer

		RegisterForSingleLOSGain(GetActorReference(), Game.GetPlayer() as Actor)
	EndIf

	if MakeAggressiveOnDistanceToPlayer > 0

		RegisterForSingleUpdate(1)
	EndIf

	(GetOwningQuest() as _D_QuestMurder).pacifyAlias(self)

EndEvent




