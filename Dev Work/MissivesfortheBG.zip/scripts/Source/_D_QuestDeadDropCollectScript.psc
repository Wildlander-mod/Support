;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 20
Scriptname _D_QuestDeadDropCollectScript Extends Quest Hidden

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY City
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_City Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY DeadDrop
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_DeadDrop Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY recipient
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_recipient Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Priest
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Priest Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY DeadDropMarker
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Marker Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Container
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Container Auto
;END ALIAS PROPERTY


;BEGIN ALIAS PROPERTY OtherHold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_OtherHold Auto
;END ALIAS PROPERTY

;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE
SetObjectiveDisplayed(20)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_10
Function Fragment_10()
;BEGIN CODE
;Stage 105  - Fail objectives 

FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE
;Stage 30

Alias_Item.TryToEnable()
ObjectReference containerRef = Alias_Container.GetRef()
containerRef.RemoveItem(Alias_Item.GetRef())

DeliveryDate.SetValue((GameDaysPassed.GetValue() + Duration.GetValue()) as int)
UpdateCurrentInstanceGlobal(DeliveryDate)

Game.GetPlayer().AddItem(Alias_Item.GetRef())
Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)
SetObjectiveCompleted(20)
SetStage(40)


Alias_recipient.GetRef().Enable()
	
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_15
Function Fragment_15()
;BEGIN CODE

;Stage 103 - Quest failed and issue bounty

int OldCrimeGold = CrimeFaction.GetCrimeGold()  ;get bounty before we increase it

Utility.Wait(0.10)
Alias_Item.GetRef().SetActorOwner(Alias_Recipient.GetActorRef().GetActorBase())
CrimeFaction.ModCrimeGold(GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue())

Game.IncrementStat("Items Stolen")
int NewCrimeGold = CrimeFaction.GetCrimeGold() ;get bounty after we increase it

Debug.Notification((NewCrimeGold - OldCrimeGold) + " bounty from Failing Missive")



SetStage(105)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_12
Function Fragment_12()
;BEGIN CODE

;Stage 110 clean up quest

if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")

while(Alias_recipient.GetRef().Is3DLoaded())
	Utility.Wait(1.0)
endWhile

Alias_recipient.GetRef().Disable()

endIf

Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_8
Function Fragment_8()
;BEGIN CODE
; Quest stage 100 - Complete Quest

CompleteAllObjectives()
Game.GetPlayer().RemoveItem(Alias_Item.GetRef())

int RewardValue = Alias_Item.GetRef().GetBaseObject().getGoldValue() as int

RewardValue = RewardValue + GoldReward.GetValue() as int
	
Game.GetPlayer().AddItem(Gold001, RewardValue)

SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_3
Function Fragment_3()
;BEGIN CODE
; Quest shutdown Stage 250 - PLAYER destroyed item

  setStage(103)

;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

GlobalVariable Property GameDaysPassed  Auto  

GlobalVariable Property DeliveryDate  Auto  

GlobalVariable Property duration  Auto  

GlobalVariable Property GoldReward  Auto  

MiscObject Property Gold001  Auto  

Faction Property CrimeFaction  Auto  
