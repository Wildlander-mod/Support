;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 10
Scriptname _D_QuestTrackRunnerScript Extends Quest Hidden


;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY RaggedFlagon
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_RaggedFlagon Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker1
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker2
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker2 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY OtherHold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_OtherHold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY NearestFence
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_NearestFence Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Runner
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Runner Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Mine
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Mine Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE

Alias_Missive.GetRef().Enable()
Game.GetPlayer().AddItem(Alias_Missive.GetRef())

Alias_Runner.GetRef().Enable()
Alias_Runner.GetActorRef().Enable()
Alias_Runner.GetActorRef().MoveTo(Alias_InnMarker1.getref())

Alias_Item.GetRef().Enable()
Alias_Runner.GetRef().AddItem(Alias_Item.GetRef())

SetObjectiveDisplayed(20)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_3
Function Fragment_3()
;BEGIN CODE
CompleteAllObjectives()
Game.GetPlayer().RemoveItem(Alias_Item.GetRef())
Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE

if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

while(Alias_Runner.GetRef().Is3DLoaded())
Utility.Wait(1.0)
endWhile
Alias_Runner.GetRef().Disable()

Stop()
;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  
