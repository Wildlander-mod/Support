;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 1
Scriptname _D_QuestFrame Extends Quest Hidden

;BEGIN ALIAS PROPERTY City
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_City Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Location
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Location Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY ItemContainer
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_ItemContainer Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY NearestFence
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_NearestFence Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Boss
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Boss Auto
;END ALIAS PROPERTY

Import PO3_Events_Form

;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE

;debug.trace("Steal Missive picked up")

KilledThief.SetValue(0)
UpdateCurrentInstanceGlobal(KilledThief)
InJail.SetValue(0)
UpdateCurrentInstanceGlobal(InJail)

SetObjectiveDisplayed(20)

if(Game.GetPlayer().GetItemCount(Alias_Item.GetRef()))
	SetObjectiveCompleted(20)
	SetObjectiveDisplayed(30)
endIf

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE

DeliveryDate.SetValue((GameDaysPassed.GetValue() + Duration.GetValue()) as int)
UpdateCurrentInstanceGlobal(DeliveryDate)

Alias_Item.TryToEnable()
Game.GetPlayer().AddItem(Alias_Item.GetRef())
Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)

SetObjectiveCompleted(20)
SetObjectiveDisplayed(30)

;END CODE
EndFunction
;END FRAGMENT



;BEGIN FRAGMENT Fragment_3
Function Fragment_3()
;BEGIN CODE
CompleteAllObjectives()

int RewardValue = Alias_Item.GetRef().GetBaseObject().getGoldValue() * 2
Game.GetPlayer().RemoveItem(Alias_Item.GetRef())
Game.GetPlayer().AddItem(Gold001, RewardValue)
SetStage(110)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT



;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

if(Alias_ItemContainer.GetRef().GetItemCount(Alias_Item.GetRef()) > 0)
	Alias_ItemContainer.GetRef().RemoveItem(Alias_Item.GetRef())
endIf

if(Game.GetPlayer().GetItemCount(Alias_Item.GetRef()) > 0)
	Game.GetPlayer().RemoveItem(Alias_Item.GetRef())
endIf

UnregisterForUpdate()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_10
Function Fragment_10()
;BEGIN CODE
; Quest shutdown Stage 250 - PLAYER ARRESTED

	FailAllObjectives()
	
	if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
	Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Board")
	elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
	Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Player")
	else 
	Alias_Missive.GetRef().delete()
	endIf

	Alias_Item.GetRef().delete()
	
	UnregisterForUpdate()
	stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_15
Function Fragment_15()
;BEGIN CODE

; Quest shutdown Stage 103 - Quest failed - Delivery not met.


	Alias_Item.GetRef().SetActorOwner(Alias_Boss.GetActorRef().GetActorBase())

	int Bounty = GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue()

	SetBounty(Alias_Boss.GetActorRef() as actor , Bounty)

	SetStage(105)

;END CODE
EndFunction
;END FRAGMENT

Event OnQuestStageChange(Quest akQuest, Int aiNewStage)				; function from po3 papyrus extender.	; moved to quest script

	if aiNewStage == 30
		RegisterForUpdate(0.1)
		;debug.trace("starting crime tracking")
	endif
EndEvent

Event OnUpdate()

	if GlobJail.Getvalue() == 1 
		InJail.SetValue(1)
		UpdateCurrentInstanceGlobal(InJail)
		GlobJail.SetValue(0)
		UpdateCurrentInstanceGlobal(GlobJail)
		FailAllObjectives()
		Setstage(250)
	endIf
endEvent


;END FRAGMENT CODE - Do not edit anything between this and the begin comment

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  


GlobalVariable Property KilledThief  Auto  
GlobalVariable Property InJail       Auto  
GlobalVariable Property GlobJail   Auto  

GlobalVariable Property GameDaysPassed  Auto  

GlobalVariable Property DeliveryDate  Auto  

GlobalVariable Property duration  Auto  


Function SetBounty(Actor target, int amount) ;This function will increase the player's bounty for the specific region he is in by a specific amount 

	Game.IncrementStat("Items Stolen")
	
	Location EastmarchHoldLocation = Game.GetFormFromFile(0x01676A, "Skyrim.esm") as Location
	Location FalkreathHoldLocation = Game.GetFormFromFile(0x01676F, "Skyrim.esm") as Location
	Location HaafingarHoldLocation = Game.GetFormFromFile(0x016770, "Skyrim.esm") as Location
	Location HjaalmarchHoldLocation = Game.GetFormFromFile(0x01676E, "Skyrim.esm") as Location
	Location PaleHoldLocation = Game.GetFormFromFile(0x01676D, "Skyrim.esm") as Location
	Location ReachHoldLocation = Game.GetFormFromFile(0x016769, "Skyrim.esm") as Location
	Location RiftHoldLocation = Game.GetFormFromFile(0x01676C, "Skyrim.esm") as Location
	Location WhiterunHoldLocation = Game.GetFormFromFile(0x016772, "Skyrim.esm") as Location
	Location WinterholdHoldLocation = Game.GetFormFromFile(0x01676B, "Skyrim.esm") as Location
	Location DLC2SolstheimLocation = Game.GetFormFromFile(0x016E2A, "Dragonborn.esm") as Location

	Faction CrimeFactionEastmarch  = Game.GetFormFromFile(0x0267E3, "Skyrim.esm") as faction
	Faction CrimeFactionFalkreath  = Game.GetFormFromFile(0x028170, "Skyrim.esm") as faction
	Faction CrimeFactionHaafingar  = Game.GetFormFromFile(0x029DB0, "Skyrim.esm") as faction
	Faction CrimeFactionReach = Game.GetFormFromFile(0x02816C, "Skyrim.esm") as faction
	Faction CrimeFactionHjaalmarch = Game.GetFormFromFile(0x02816D, "Skyrim.esm") as faction
	Faction CrimeFactionPale = Game.GetFormFromFile(0x02816E, "Skyrim.esm") as faction
	Faction CrimeFactionRift = Game.GetFormFromFile(0x02816B, "Skyrim.esm") as faction
	Faction CrimeFactionWhiterun = Game.GetFormFromFile(0x0267EA, "Skyrim.esm") as faction
	Faction CrimeFactionWinterhold = Game.GetFormFromFile(0x02816F, "Skyrim.esm") as faction
	Faction CrimeFactionSolstheim = Game.GetFormFromFile(0x018279, "Dragonborn.esm") as faction
	
	Faction Currentlocation = CrimeFactionWhiterun as faction
 
	If target.IsInLocation(WhiterunHoldLocation)
		 Currentlocation = CrimeFactionWhiterun

	elseif target.IsInLocation(FalkreathHoldLocation)
		 Currentlocation = CrimeFactionFalkreath 
	elseif target.IsInLocation(EastmarchHoldLocation)
		 Currentlocation = CrimeFactionEastmarch 

	elseif target.IsInLocation(HaafingarHoldLocation)
		 Currentlocation = CrimeFactionHaafingar 

	elseif target.IsInLocation(ReachHoldLocation)
		 Currentlocation = CrimeFactionReach 

	elseif target.IsInLocation(HjaalmarchHoldLocation)
		 Currentlocation = CrimeFactionHjaalmarch 
 
	elseif target.IsInLocation(PaleHoldLocation)
		 Currentlocation = CrimeFactionPale
 
	elseif target.IsInLocation(RiftHoldLocation)
		 Currentlocation = CrimeFactionRift 
 
	elseif target.IsInLocation(WinterholdHoldLocation)
		 Currentlocation = CrimeFactionWinterhold 

	endif
	
	int OldCrimeGold = Currentlocation.GetCrimeGold() ;get bounty before we increase it

	Utility.Wait(0.10)
	Alias_Item.GetRef().SetActorOwner(target.GetActorBase())
	Currentlocation.ModCrimeGold(GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue())
	Game.IncrementStat("Items Stolen")

	int NewCrimeGold = Currentlocation.GetCrimeGold() ;get bounty after we increase it
	Debug.Notification((NewCrimeGold - OldCrimeGold) + " bounty from Failing Missive")

 
EndFunction


