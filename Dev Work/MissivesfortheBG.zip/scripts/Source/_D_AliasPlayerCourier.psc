Scriptname _D_AliasPlayerCourier extends ReferenceAlias

GlobalVariable Property DeliveryDate Auto
GlobalVariable Property GameDaysPassed Auto

Event OnInit()
	RegisterForUpdateGameTime(0.1)
endEvent

Event OnUpdateGameTime()
	if(GetOwningQuest().GetStage() > 20 && GetOwningQuest().GetStage() < 100 && GetOwningQuest().IsObjectiveCompleted(20))
	
		if(GameDaysPassed.GetValue() > DeliveryDate.GetValue())
			
			GetOwningQuest().SetStage(103)
		endIf
	endIf
endEvent