scriptName _D_AliasIntelLedgerScript extends ReferenceAlias conditional

;-- Properties --------------------------------------
sound property NPCHumanWritingTG auto
ReferenceAlias property Alias_noteAlias auto
quest property _m_QuestIntelGather auto


;-- Variables ---------------------------------------

;-- Functions ---------------------------------------

; Skipped compiler generated GetState

Event OnLoad()

	Self.GetRef().BlockActivation()

EndEvent

Event OnActivate(ObjectReference akActionRef)

	Self.GetRef().GetLinkedRef().SendStealAlarm(Game.GetPlayer())

	if akActionRef == Game.GetPlayer()
		if _m_QuestIntelGather.GetStage() < 50
			NPCHumanWritingTG.Play(self.GetRef())
			game.GetPlayer().AddItem(Alias_noteAlias.GetRef() as form, 1, false)
			_m_QuestIntelGather.SetStage(40)
		endIf
	endif

EndEvent


