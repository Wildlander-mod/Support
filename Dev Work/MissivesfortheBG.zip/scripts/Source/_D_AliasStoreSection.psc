Scriptname _D_AliasStoreSection extends ReferenceAlias  

ReferenceAlias Property TargetContainer Auto

Event OnContainerChanged(ObjectReference newContainer, ObjectReference oldContainer)
	 
if (GetOwningQuest().GetStage() == 20) 
	if (newContainer == TargetContainer.getRef()) 
			GetOwningQuest().SetObjectivecompleted(20)  
			GetOwningQuest().setstage(40)
			GetOwningQuest().SetObjectiveDisplayed(40)
		endif 
	endif
EndEvent
