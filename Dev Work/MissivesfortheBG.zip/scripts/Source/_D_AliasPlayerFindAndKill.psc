Scriptname _D_AliasPlayerFindAndKill extends ReferenceAlias

LocationAlias Property EndLocation Auto 

Event OnLocationChange(Location akOldLoc, Location akNewLoc)

	if(GetOwningQuest().GetStage() == 20)
	  if (EndLocation.GetLocation()  == akNewLoc)
		GetOwningQuest().SetStage(105)
	  endIf
	endIf
  
endEvent

