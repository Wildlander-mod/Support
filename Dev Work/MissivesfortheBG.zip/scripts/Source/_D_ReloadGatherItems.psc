ScriptName _D_ReloadGatherItems extends ReferenceAlias
 
Event OnPlayerLoadGame()

	(GetOwningQuest() as _D_QuestGatherDestScript).Book()
EndEvent