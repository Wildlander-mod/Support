;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 0
Scriptname _D_QuestShadyCourierScript Extends Quest Hidden

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY NearestFence
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_NearestFence Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Recipient
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Recipient Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY City
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_City Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY OtherHold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_OtherHold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Inn1
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Inn1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker1
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Inn2
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Inn2 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker2
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker2 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY SupplierLocation
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_SupplierLocation Auto
;END ALIAS PROPERTY

;BEGIN FRAGMENT Fragment_10
Function Fragment_10()
;BEGIN CODE
; Quest shutdown Stage 105 - Recipient dies.


	FailAllObjectives()
	SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE

; Quest Startup Stage 20.

	SetObjectiveDisplayed(20)

	Alias_Item.GetRef().Enable()

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_12
Function Fragment_12()
;BEGIN CODE
	; Quest shutdown Stage 110.
	

	if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
	Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Board")
	elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
	Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Player")
	endIf

	while(Alias_Recipient.GetRef().Is3DLoaded())
		Utility.Wait(1.0)
	endWhile
	
	Alias_Recipient.GetRef().Disable()

	Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_15
Function Fragment_15()
;BEGIN CODE

; Quest shutdown Stage 103 - Quest failed - Delivery not met.


	Alias_Item.GetRef().SetActorOwner(Alias_QuestGiver.GetActorRef().GetActorBase())

	int Bounty = GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue()

	SetBounty(Alias_QuestGiver.GetActorRef() as actor , Bounty)

	SetStage(105)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_8
Function Fragment_8()
;BEGIN CODE
; Quest shutdown Stage 100 - Quest Complete - Delivery.

	CompleteAllObjectives()
	Game.GetPlayer().RemoveItem(Alias_Item.GetRef())
	Game.GetPlayer().AddItem(Gold001, Alias_Item.GetRef().GetBaseObject().getGoldValue() as int)

	If (Game.GetPlayer().GetCurrentLocation() != Alias_Inn1.GetLocation() && Game.GetPlayer().GetCurrentLocation() != Alias_Inn2.GetLocation() )
		Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)
	endif

	SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE
; Quest Start Stage 30 - Quest - Delivery Accepted.

	Alias_Item.TryToEnable()
	Game.GetPlayer().AddItem(Alias_Item.GetRef())

	DeliveryDate.SetValue((GameDaysPassed.GetValue() + Duration.GetValue()) as int)
	UpdateCurrentInstanceGlobal(DeliveryDate)

	SetObjectiveCompleted(20)
	SetStage(40)

;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

GlobalVariable Property GameDaysPassed  Auto  

GlobalVariable Property DeliveryDate  Auto  

GlobalVariable Property duration  Auto  

GlobalVariable Property GoldReward  Auto  

MiscObject Property Gold001  Auto  

ObjectReference property myPoison  auto hidden


Function SetBounty(Actor target, int amount) ;This function will increase the player's bounty for the specific region he is in by a specific amount 

	Game.IncrementStat("Items Stolen")
	
	Location EastmarchHoldLocation = Game.GetFormFromFile(0x01676A, "Skyrim.esm") as Location
	Location FalkreathHoldLocation = Game.GetFormFromFile(0x01676F, "Skyrim.esm") as Location
	Location HaafingarHoldLocation = Game.GetFormFromFile(0x016770, "Skyrim.esm") as Location
	Location HjaalmarchHoldLocation = Game.GetFormFromFile(0x01676E, "Skyrim.esm") as Location
	Location PaleHoldLocation = Game.GetFormFromFile(0x01676D, "Skyrim.esm") as Location
	Location ReachHoldLocation = Game.GetFormFromFile(0x016769, "Skyrim.esm") as Location
	Location RiftHoldLocation = Game.GetFormFromFile(0x01676C, "Skyrim.esm") as Location
	Location WhiterunHoldLocation = Game.GetFormFromFile(0x016772, "Skyrim.esm") as Location
	Location WinterholdHoldLocation = Game.GetFormFromFile(0x01676B, "Skyrim.esm") as Location
	Location DLC2SolstheimLocation = Game.GetFormFromFile(0x016E2A, "Dragonborn.esm") as Location

	Faction CrimeFactionEastmarch  = Game.GetFormFromFile(0x0267E3, "Skyrim.esm") as faction
	Faction CrimeFactionFalkreath  = Game.GetFormFromFile(0x028170, "Skyrim.esm") as faction
	Faction CrimeFactionHaafingar  = Game.GetFormFromFile(0x029DB0, "Skyrim.esm") as faction
	Faction CrimeFactionReach = Game.GetFormFromFile(0x02816C, "Skyrim.esm") as faction
	Faction CrimeFactionHjaalmarch = Game.GetFormFromFile(0x02816D, "Skyrim.esm") as faction
	Faction CrimeFactionPale = Game.GetFormFromFile(0x02816E, "Skyrim.esm") as faction
	Faction CrimeFactionRift = Game.GetFormFromFile(0x02816B, "Skyrim.esm") as faction
	Faction CrimeFactionWhiterun = Game.GetFormFromFile(0x0267EA, "Skyrim.esm") as faction
	Faction CrimeFactionWinterhold = Game.GetFormFromFile(0x02816F, "Skyrim.esm") as faction
	Faction CrimeFactionSolstheim = Game.GetFormFromFile(0x018279, "Dragonborn.esm") as faction
	
	Faction Currentlocation = CrimeFactionWhiterun as faction
 
	If target.IsInLocation(WhiterunHoldLocation)
		 Currentlocation = CrimeFactionWhiterun

	elseif target.IsInLocation(FalkreathHoldLocation)
		 Currentlocation = CrimeFactionFalkreath 
	elseif target.IsInLocation(EastmarchHoldLocation)
		 Currentlocation = CrimeFactionEastmarch 

	elseif target.IsInLocation(HaafingarHoldLocation)
		 Currentlocation = CrimeFactionHaafingar 

	elseif target.IsInLocation(ReachHoldLocation)
		 Currentlocation = CrimeFactionReach 

	elseif target.IsInLocation(HjaalmarchHoldLocation)
		 Currentlocation = CrimeFactionHjaalmarch 
 
	elseif target.IsInLocation(PaleHoldLocation)
		 Currentlocation = CrimeFactionPale
 
	elseif target.IsInLocation(RiftHoldLocation)
		 Currentlocation = CrimeFactionRift 
 
	elseif target.IsInLocation(WinterholdHoldLocation)
		 Currentlocation = CrimeFactionWinterhold 

	endif
	
	int OldCrimeGold = Currentlocation.GetCrimeGold() ;get bounty before we increase it

	Utility.Wait(0.10)
	Alias_Item.GetRef().SetActorOwner(target.GetActorBase())
	Currentlocation.ModCrimeGold(GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue())
	Game.IncrementStat("Items Stolen")

	int NewCrimeGold = Currentlocation.GetCrimeGold() ;get bounty after we increase it
	Debug.Notification((NewCrimeGold - OldCrimeGold) + " bounty from Failing Missive")

 
EndFunction


