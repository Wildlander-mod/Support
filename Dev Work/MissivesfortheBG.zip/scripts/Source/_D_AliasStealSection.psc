Scriptname _D_AliasStealSection extends ReferenceAlias  


Event OnContainerChanged(ObjectReference newContainer, ObjectReference oldContainer)
	 
if (GetOwningQuest().GetStage() == 20) 
if (newContainer == Game.GetPlayer()) 
		GetOwningQuest().SetObjectivecompleted(20)  
		GetOwningQuest().setstage(40)
	    GetOwningQuest().SetObjectiveDisplayed(40)
	endif 
endif
EndEvent
