scriptName _D_AliasDeadDropItemCollectScript extends ReferenceAlias conditional

;-- Properties --------------------------------------
ReferenceAlias property Alias_ItemAlias auto
ReferenceAlias property Alias_recipient  auto
quest property _m_QuestMissive auto


;-- Variables ---------------------------------------

;-- Functions ---------------------------------------

; Skipped compiler generated GetState

function OnActivate(objectreference akActionRef)

	if akActionRef == game.GetPlayer() as objectreference 
		if GetOwningQuest().GetStage() == 20
			GetOwningQuest().SetStage(30)
			debug.notification("The dead drop glowing runes fall inert as you remove the item." )

			Alias_recipient.GetRef().Enable()
		endIf
	endIf
endFunction