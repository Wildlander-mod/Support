;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 1
Scriptname _D_QuestDeliverNote Extends Quest Hidden

;BEGIN ALIAS PROPERTY City
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_City Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Location
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Location Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Note
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Note Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY NoteContainer
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_NoteContainer Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY NearestFence
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_NearestFence Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

Import PO3_Events_Form

;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE

KilledOwner.SetValue(0)
UpdateCurrentInstanceGlobal(KilledOwner)

Game.GetPlayer().AddItem(Alias_Note.GetRef())

SetObjectiveDisplayed(20)

;END CODE
EndFunction
;END FRAGMENT


;BEGIN FRAGMENT Fragment_3
Function Fragment_3()
;BEGIN CODE
CompleteAllObjectives()



Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)
SetStage(110)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT



;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

if(Alias_NoteContainer.GetRef().GetItemCount(Alias_Note.GetRef()) > 0)
	Alias_NoteContainer.GetRef().RemoveItem(Alias_Note.GetRef())
endIf

if(Game.GetPlayer().GetItemCount(Alias_Note.GetRef()) > 0)
	Game.GetPlayer().RemoveItem(Alias_Note.GetRef())
endIf

UnregisterForUpdate()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_10
Function Fragment_10()
;BEGIN CODE
; Quest shutdown Stage 250 - PLAYER ARRESTED

	FailAllObjectives()
	
	if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
	Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Board")
	elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
	Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Player")
	else 
	Alias_Missive.GetRef().delete()
	endIf

	Alias_Note.GetRef().delete()
	
	UnregisterForUpdate()
	stop()
;END CODE
EndFunction
;END FRAGMENT


;END FRAGMENT CODE - Do not edit anything between this and the begin comment

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

GlobalVariable Property KilledOwner  Auto  
