scriptName _D_QuestIntelGatheringMain extends Quest hidden

;-- Properties --------------------------------------
locationalias property Alias_Business auto
referencealias property Alias_Fence auto
referencealias property Alias_MissiveBoard auto
keyword property TGBusiness auto
referencealias property Alias_Ledger auto
referencealias property Alias_Missive auto
locationalias property Alias_City auto
referencealias property Alias_containerAlias auto
referencealias property Alias_Boss auto
referencealias property Alias_noteAlias auto

;-- Variables ---------------------------------------

Import PO3_Events_Form


;-- Functions ---------------------------------------

function Fragment_0()
	self.SetObjectiveDisplayed(20, 1 as Bool, false)
endFunction

function Fragment_1()
	KilledThief.SetValue(0)
	UpdateCurrentInstanceGlobal(KilledThief)
	InJail.SetValue(0)
	UpdateCurrentInstanceGlobal(InJail)

    ; Quest Move to return Stage 40 - Forge Collected.
	self.SetObjectiveCompleted(20, 1 as Bool)
	self.SetObjectiveDisplayed(40, 1 as Bool, false)
endFunction

;BEGIN FRAGMENT Fragment_8
Function Fragment_8()
;BEGIN CODE
    ; Quest shutdown Stage 100 - Quest Complete - Delivery.

    CompleteAllObjectives()
	Game.GetPlayer().RemoveItem(Alias_noteAlias.GetRef())

	Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)
    SetStage(110)
;END CODE
EndFunction
;END FRAGMENT


Function Fragment_3()
; Quest shutdown Stage 250 - PLAYER ARRESTED

	FailAllObjectives()

	Alias_noteAlias.GetRef().delete()

	if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
		Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Board")
	elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
		Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Player")
	else 
		Alias_Missive.GetRef().delete()
	endIf

	UnregisterForUpdate()
    stop()
EndFunction


;BEGIN FRAGMENT Fragment_15
Function Fragment_15()
;BEGIN CODE
; Quest shutdown Stage 103 - Quest failed - Delivery not met.

SetStage(105)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_10
Function Fragment_10()
;BEGIN CODE
; Quest shutdown Stage 105 - Recipient dies.
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT


function Fragment_12()

	if Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef() as form) > 0
		Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef() as form, 1, false, none)
	elseIf game.GetPlayer().GetItemCount(Alias_Missive.GetRef() as form) > 0
		game.GetPlayer().RemoveItem(Alias_Missive.GetRef() as form, 1, false, none)
		Alias_noteAlias.GetRef().delete()
		po3_sksefunctions.ClearReadFlag(Alias_noteAlias.GetRef().GetBaseObject() as book)
	endIf
	po3_sksefunctions.ClearReadFlag(Alias_Missive.GetRef().GetBaseObject() as book)
	
	UnregisterForUpdate()
	self.Stop()
endFunction

Event OnQuestStageChange(Quest akQuest, Int aiNewStage)				; function from po3 papyrus extender.	; moved to quest script


	if aiNewStage == 40
		RegisterForUpdate(0.1)
		;debug.trace("starting crime tracking")
	endif
EndEvent

Event OnUpdate()

	if GlobJail.Getvalue() == 1 
		InJail.SetValue(1)
		UpdateCurrentInstanceGlobal(InJail)
		GlobJail.SetValue(0)
		UpdateCurrentInstanceGlobal(GlobJail)
		FailAllObjectives()
		SetStage(250)
	endIf
endEvent

GlobalVariable Property GoldReward  Auto  

MiscObject Property Gold001  Auto  

GlobalVariable Property KilledThief  Auto  
GlobalVariable Property InJail       Auto  
GlobalVariable Property GlobJail   Auto  

