Scriptname _D_AliasPickpocketRoute extends referencealias

Event OnContainerChanged(ObjectReference newContainer, ObjectReference oldContainer)

if (GetOwningQuest().GetStage() == 20) 
 if (newContainer == Game.GetPlayer()) 
		GetOwningQuest().SetObjectivecompleted(20)  
		GetOwningQuest().setstage(40)
		GetOwningQuest().SetObjectivedisplayed(40)
	endif 
endif

	
EndEvent	

