Scriptname _D_QuestMurder Extends Quest Hidden

;BEGIN ALIAS PROPERTY Horse01
;ALIAS PROPERTY TYPE referencealias
referencealias Property Alias_Horse01 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Bodyguard01
;ALIAS PROPERTY TYPE referencealias
referencealias Property Alias_Bodyguard01 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Inn2
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Inn2 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY OtherHold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_OtherHold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker2
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker2 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Fence
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Fence Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Inn1
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Inn1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Noble
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Noble Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY InnMarker1
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_InnMarker1 Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE

SetObjectiveDisplayed(20)

Actor Horse01 = Alias_Horse01.getReference() as Actor
Actor Noble01 = Alias_Noble.getReference() as Actor

horse01.setFactionOwner(WERoad02NobleFaction)

if(Alias_Noble.GetActorRef().IsDead())
	SetObjectiveCompleted(20)
	SetObjectiveDisplayed(40)
endIf

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_4
Function Fragment_4()
;BEGIN CODE
CompleteAllObjectives()
Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)
SetStage(110)

Alias_Noble.GetReference().DeleteWhenAble()
Alias_Bodyguard01.GetReference().DeleteWhenAble()

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_8
Function Fragment_8()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

while(Alias_Noble.GetRef().Is3DLoaded())
Utility.Wait(1.0)
endWhile

Alias_Noble.GetReference().DeleteWhenAble()
Alias_Horse01.GetReference().DeleteWhenAble()
Alias_Bodyguard01.GetReference().DeleteWhenAble()

Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
SetObjectiveCompleted(20)
SetObjectiveDisplayed(40)

pacifyAlias(Alias_Horse01)

;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

Faction Property WERoad02NobleFaction Auto

function makeAliasAggressiveAndAttackPlayer(ReferenceAlias AliasToAnger)

	if(!AliasToAnger.GetActorRef().IsDead())

		Actor ActorRef = AliasToAnger.GetActorReference()

		if actorRef.GetActorValue("Aggression") < 2
			actorRef.SetActorValue("Aggression", 2) 
		EndIf

		actorRef.startCombat(Game.GetPlayer())

	endif
	
EndFunction


Function pacifyAlias(ReferenceAlias AliasToPacify)

	Actor ActorRef = AliasToPacify.GetActorReference()

	actorRef.SetActorValue("Aggression", 0) 
	
	actorRef.StopCombat()
	
EndFunction




