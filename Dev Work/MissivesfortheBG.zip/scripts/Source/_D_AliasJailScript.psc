Scriptname _D_AliasJailScript extends ReferenceAlias  

Quest Property QuestID Auto

Import PO3_Events_Form

Event OnInit()
	RegisterForQuestStage(QuestID, (getOwningQuest() As Quest))
EndEvent


GlobalVariable Property pFailQuest Auto   