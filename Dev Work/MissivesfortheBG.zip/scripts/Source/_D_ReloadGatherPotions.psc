ScriptName _D_ReloadGatherPotions extends ReferenceAlias
 
Event OnPlayerLoadGame()

	(GetOwningQuest() as _D_QuestGatherPotionDestScript).Maintenance()
EndEvent