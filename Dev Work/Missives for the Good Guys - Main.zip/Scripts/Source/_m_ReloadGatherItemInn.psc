ScriptName _m_ReloadGatherItemInn extends ReferenceAlias
 
Event OnPlayerLoadGame()

	(GetOwningQuest() as _M_QuestGatherInnScript).Book()

EndEvent