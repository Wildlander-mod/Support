;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 11
Scriptname _M_QuestGatherPotionDestMultScript Extends Quest Hidden

import _m_MissivesUtils

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY    

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

import PO3_SKSEFunctions

Event OnInit()
    ; Try to get the GlobalVariable from Requiem.esp
     GlobalVariable tempVar = Game.GetFormFromFile(0xAD3A1B, "Requiem.esp") as GlobalVariable
    
    if tempVar != None
        REQ_Internal_Player_Is_In_Training = tempVar
    else
        Debug.Trace("Requiem.esp is NOT in the load order. Using default behavior.")
    endif
	
	ItemTotal.SetValue(Utility.RandomInt(ItemTotalMin.GetValue() as int, ItemTotalMax.GetValue() as int))
	UpdateCurrentInstanceGlobal(ItemTotal)

	keyword MissiveSettlement = Game.GetFormFromFile(0xF40, "MissivesfortheGoodGuys.esp") as keyword
	
	if !Alias_Destination

		if Alias_QuestGiver
			Location npcLoc    = Alias_QuestGiver.getRef().GetCurrentLocation()
			
			if npcLoc != None && npcLoc.HasKeyword(MissiveSettlement)
				Alias_Destination.ForceLocationTo(npcLoc)
			else	
				Location parentLoc = GetParentLocation(npcLoc)
				
				if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
					Alias_Destination.ForceLocationTo(parentLoc)
				else
					parentLoc = GetParentLocation(parentLoc)
					
					if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
						Alias_Destination.ForceLocationTo(parentLoc)
					endif	
				endif			
			endif
		endIf
	endif
EndEvent

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
	
SetObjectiveDisplayed(20)

Actor player = Game.GetPlayer()

CheckInventoryforPotions(player)


;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
CompleteAllObjectives()

int RewardValue = GoldReward.GetValue() as int

int Required = ItemCount.GetValue()  as int

Int Index = 0

int count = potionList.GetSize()
int i = 0

Actor player = Game.GetPlayer()

Debug.Trace("=== Potion Removal Loop Start ===")
Debug.Trace("Required initial: " + Required)

while i < count && Required > 0

    Form itemForm = potionList.GetAt(i)
    Debug.Trace("Checking index " + i + ": " + itemForm)

    if itemForm
        Int L = player.GetItemCount(itemForm)
        Debug.Trace("Player has " + L + " of " + itemForm)

        if L > 0
            Int removeCount = L

            ; Cap to Required
            if removeCount > Required
                removeCount = Required
            endif

            Debug.Trace("Removing " + removeCount + " of " + itemForm)

            Game.GetPlayer().RemoveItem(itemForm, removeCount)

            Int valueEach = itemForm.GetGoldValue() as Int
            Int totalValue = valueEach * removeCount

            RewardValue += totalValue
            Required -= removeCount

            Debug.Trace("Value each: " + valueEach)
            Debug.Trace("Total value added: " + totalValue)
            Debug.Trace("RewardValue now: " + RewardValue)
            Debug.Trace("Required remaining: " + Required)
        else
            Debug.Trace("Player has none of this item.")
        endif
    else
        Debug.Trace("itemForm was NONE at index " + i)
    endif

    i += 1
endWhile

Debug.Trace("=== Potion Removal Loop End ===")
Debug.Trace("Final RewardValue: " + RewardValue)
Debug.Trace("Final Required: " + Required)




Game.GetPlayer().AddItem(Gold001, RewardValue)
Game.GetPlayer().AddItem(Reward)

REQ_Internal_Player_Is_In_Training.SetValueInt(1)

ActorValueInfo skill = ActorValueInfo.GetActorValueInfoByID(16) ; Alchemy

Float baseLevel = skill.GetBaseValue(Game.GetPlayer())
Float xpRequired = 0.0

If baseLevel <= 0.0
	xpRequired = skill.GetSkillOffsetMult()
Else
	xpRequired = (Math.Pow(baseLevel, 1.95) * skill.GetSkillImproveMult()) + skill.GetSkillOffsetMult()
EndIf

If baseLevel < 90 && xpRequired > 0.0
	Game.AdvanceSkill("Alchemy", xpRequired)
Else
	Debug.Notification("<Alias=questgiver> won't teach me anything without any skill in the topic.")
EndIf


REQ_Internal_Player_Is_In_Training.SetValueInt(0)

SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_13
Function Fragment_13()

;BEGIN CODE

    ; Debug.Trace("Stage 5: Missive Setup - Select effect")

	Maintenance()

;END CODE
EndFunction  
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment


Function PotionAdded(potion Potionbase, Objectreference akItemReference)

	bool notusedbycurrentquest 
	bool IsRequiredPotion = isPotionofType( Potionbase,  PotionEffect )	
	
	If GetStage() == 20 
	
		if IsObjectiveDisplayed(20)  && akItemReference.GetNumReferenceAliases() > 0 
			;Can't use this one is already attached to quest objectives
			notusedbycurrentquest = true
		endif

		if !notusedbycurrentquest

			form Potionsref = akItemReference as form
					
			if IsRequiredPotion && !(potionList.HasForm(Potionsref))
				ItemCount.SetValue(ItemCount.getValue() + 1)
				UpdateCurrentInstanceGlobal(ItemCount)

				potionList.AddForm(Potionsref)
			endIf

			if(ItemCount.GetValue() >= ItemTotal.GetValue() && !IsObjectiveDisplayed(40))
				SetObjectiveCompleted(20)
				SetObjectiveDisplayed(40, true, true)
			endIf
		endif
	endif

endFunction

Function PotionRemoved(potion Potionbase, Objectreference akItemReference)

	bool IsRequiredPotion = isPotionofType( Potionbase,  PotionEffect )
	
	form Potionsref = akItemReference as form
	
	If GetStage() == 20 		
		if IsRequiredPotion	 && (potionList.HasForm(Potionsref))
			Actor player = Game.GetPlayer()

			CheckInventoryforPotions(player)
		endif	
			
		if(ItemCount.GetValue() < ItemTotal.GetValue() && IsObjectiveDisplayed(40))
			SetObjectiveCompleted(20, false)
			SetObjectiveDisplayed(20, true, true)
			SetObjectiveDisplayed(40, false)
		endIf
	endif

endFunction



Function RecheckInventory(form itemToDrop)

	; Need to Drop & Pickup this to detect each potion - So we remove it , then add it back to player's inventory to trigger "on item added"

	If GetStage() == 20 
		Actor player = Game.GetPlayer()
		Int L = player.GetItemCount(itemToDrop)
		
		bool IsRequiredPotion = _m_MissivesUtils.isPotionofType(itemToDrop as Potion,  PotionEffect )

		if IsRequiredPotion
			if ItemCount.GetValue() + L > ItemTotal.GetValue()
				ItemCount.SetValue(ItemTotal.GetValue())
			else	
				ItemCount.SetValue(ItemCount.GetValue() + L)
			endif
		
			PotionList.AddForm(itemToDrop)
			
			if(ItemCount.GetValue() >= ItemTotal.GetValue() && !IsObjectiveDisplayed(40))
				SetObjectiveCompleted(20)
				SetObjectiveDisplayed(40, true, true)
			endIf
		endif
	endif

EndFunction

function CheckInventoryforPotions(Actor player)

	If GetStage() == 20 
	
		int count = potionList.GetSize()
		while count > 0
			count -= 1
			ObjectReference myRef = potionList.GetAt(count) as ObjectReference
			if myRef
				potionList.RemoveAddedForm(myRef as Form)
			endif
		endWhile

		ItemCount.SetValue(0)
		UpdateCurrentInstanceGlobal(ItemCount)

		Form[] Forms = player.GetContainerForms() 
		Int L = Forms.Length 
		Int iIndex = 0 
		While iIndex < L 
			Form kItem = Forms[iIndex]
			if (kItem as Potion) 
				bool IsRequiredPotion = isPotionofType( kItem as Potion,  PotionEffect )
				
				if IsRequiredPotion
					RecheckInventory(kItem)
				endif
			endif

			iIndex += 1 
		EndWhile
	endif

endFunction

Function Maintenance()
    ; This code runs every time the game is loaded
	
	Potion ItemBase = Alias_Item.GetRef().GetBaseObject() as Potion

	PotionEffect = ItemBase.GetNthEffectMagicEffect(0)

	_m_ItemName.setName(PotionEffect.getname()) 
	
	String PotionName = PotionEffect.getname()
	
	UpdateBookTitlePotion(ItemTotal.GetValue() as int, PotionName, M_message, Alias_Destination)
EndFunction


MagicEffect PotionEffect    

formlist Property potionList auto

Message property _m_ItemName Auto

globalvariable property REQ_Internal_Player_Is_In_Training auto

GlobalVariable Property ItemCount  Auto  

GlobalVariable Property ItemTotal  Auto  

GlobalVariable Property ItemTotalMax  Auto  

GlobalVariable Property ItemTotalMin  Auto  

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

LeveledItem Property Reward  Auto  

ObjectReference Property QContainer Auto

Message property m_Message Auto