Scriptname _M_ShoppingPlayerScript extends ReferenceAlias  

Event OnItemAdded(Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akSourceContainer)
	If  GetOwningQuest().GetStage() == 50
		_M_QuestShoppingListScript SetQuest = GetOwningQuest() as _M_QuestShoppingListScript
		SetQuest.UpdateCount()
	EndIf
EndEvent

Event OnItemRemoved(Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akDestContainer)
	If  GetOwningQuest().GetStage() == 50
		_M_QuestShoppingListScript SetQuest = GetOwningQuest() as _M_QuestShoppingListScript
		SetQuest.UpdateCount()
	EndIf
EndEvent
