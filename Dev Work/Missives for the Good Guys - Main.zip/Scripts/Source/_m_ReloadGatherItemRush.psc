ScriptName _m_ReloadGatherItemRush extends ReferenceAlias
 
Event OnPlayerLoadGame()

	(GetOwningQuest() as _M_QuestGatherRushScript).Book()

EndEvent