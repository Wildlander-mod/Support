ScriptName _m_ReloadMessages extends ReferenceAlias
 
Event OnPlayerLoadGame()


	(GetOwningQuest() as _M_QuestGatherPotionDestMultScript).Maintenance()

EndEvent