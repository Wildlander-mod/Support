;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 11
Scriptname _M_QuestGatherRushScript Extends Quest Hidden

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY

;BEGIN FRAGMENT Fragment_0
Function Fragment_0()
;BEGIN CODE

 
DeliveryDate.SetValue((GameDaysPassed.GetValue() + Duration.GetValue()) as int)
UpdateCurrentInstanceGlobal(DeliveryDate)


;END CODE
EndFunction
;END FRAGMENT


;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE

ItemCount.SetValue(Game.GetPlayer().GetItemCount(Alias_Item.GetRef().GetBaseObject()))

UpdateCurrentInstanceGlobal(ItemCount)

ItemTotal.SetValue(Utility.RandomInt(ItemTotalMin.GetValue() as int, ItemTotalMax.GetValue() as int))

UpdateCurrentInstanceGlobal(ItemTotal)
	 
SetObjectiveDisplayed(20)

if (ItemCount.GetValue() >= ItemTotal.GetValue())
	SetObjectiveCompleted(20)
	SetObjectiveDisplayed(40)
endIf

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
CompleteAllObjectives()

;Debug.Trace("Missives: Quest complete")

int RewardValue = (Alias_Item.GetRef().GetBaseObject().getGoldValue() * ItemTotal.GetValue() as int) * 2

RewardValue = RewardValue + GoldReward.GetValue() as int

Game.GetPlayer().RemoveItem(Alias_Item.GetRef().GetBaseObject(), ItemTotal.GetValue() as int)
Game.GetPlayer().AddItem(Gold001, RewardValue)
Game.GetPlayer().AddItem(Reward)

REQ_Internal_Player_Is_In_Training.SetValueInt(1)

ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByName(SkillToTrain)
Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() 
game.AdvanceSkill(SkillToTrain, xpRequired)

REQ_Internal_Player_Is_In_Training.SetValueInt(0)

SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_15
Function Fragment_15()
;BEGIN CODE

SetStage(105)

;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

GlobalVariable Property ItemCount  Auto  

GlobalVariable Property ItemTotal  Auto  

GlobalVariable Property ItemTotalMax  Auto  

GlobalVariable Property ItemTotalMin  Auto  

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

LeveledItem Property Reward  Auto  

GlobalVariable Property GameDaysPassed  Auto  

GlobalVariable Property DeliveryDate  Auto  

GlobalVariable Property duration  Auto  

string Property SkillToTrain  Auto   ;https://www.creationkit.com/index.php?title=ActorValueInfo_Script#Actor_Value_IDs

globalvariable property REQ_Internal_Player_Is_In_Training auto