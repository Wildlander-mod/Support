ScriptName _m_ReloadGatherItemDest extends ReferenceAlias
 
Event OnPlayerLoadGame()

	(GetOwningQuest() as _M_QuestGatherDestScript).book()

EndEvent