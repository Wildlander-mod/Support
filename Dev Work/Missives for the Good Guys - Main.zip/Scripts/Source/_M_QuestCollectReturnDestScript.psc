;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 11
Scriptname _M_QuestCollectReturnDestScript Extends Quest Hidden

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY    

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
	
SetObjectiveDisplayed(20)

;END CODE
EndFunction
;END FRAGMENT


;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE

	Alias_Item.TryToEnable()
	Game.GetPlayer().AddItem(Alias_Item.GetRef())
	Game.GetPlayer().AddItem(Gold001, GoldReward.GetValue() as int)

	SetObjectiveCompleted(20)
	SetStage(30)
	
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
CompleteAllObjectives()

int RewardValue = Alias_Item.GetRef().GetBaseObject().getGoldValue() * ItemTotal.GetValue() as int 

RewardValue = RewardValue + GoldReward.GetValue() as int

Game.GetPlayer().RemoveItem(Alias_Item.GetRef().GetBaseObject(), ItemTotal.GetValue() as int)
Game.GetPlayer().AddItem(Gold001, RewardValue)
Game.GetPlayer().AddItem(Reward)
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

Stop()
;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

GlobalVariable Property ItemCount  Auto  

GlobalVariable Property ItemTotal  Auto  

GlobalVariable Property ItemTotalMax  Auto  

GlobalVariable Property ItemTotalMin  Auto  

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

LeveledItem Property Reward  Auto  