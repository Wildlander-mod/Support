Scriptname _M_AliasPlayerAlchemyMult extends ReferenceAlias  

ReferenceAlias Property ItemRef Auto
import _m_MissivesUtils				   

Event OnInit()
	if(ItemRef.GetRef())
		PO3_Events_Alias.RegisterForItemCrafted(self)
		RegisterForMenu("ContainerMenu")
		RegisterForMenu("Crafting Menu")
		RegisterForMenu("BarterMenu")
	endIf
endEvent

event OnMenuClose(String menuName)

	if((GetOwningQuest().getstage() > 10 && GetOwningQuest().IsObjectiveDisplayed(20)) && MenuName == "ContainerMenu" ) 
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _M_QuestGatherPotionDestMultScript).CheckInventoryforPotions(player)
		endif	
	endIf
	
	if((GetOwningQuest().getstage() > 10 && GetOwningQuest().IsObjectiveDisplayed(20)) && MenuName == "Crafting Menu" ) 
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _M_QuestGatherPotionDestMultScript).CheckInventoryforPotions(player)
		endif	
	endIf
	
	if((GetOwningQuest().getstage() > 10 && GetOwningQuest().IsObjectiveDisplayed(20)) && MenuName == "BarterMenu" ) 
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _M_QuestGatherPotionDestMultScript).CheckInventoryforPotions(player)
		endif	
	endIf
	
endEvent


Event OnItemAdded(Form akBaseItem, int aiItemCount, ObjectReference akItemReference, ObjectReference akSourceContainer)

	if (!akItemReference) && (akBaseItem as Potion) 
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _M_QuestGatherPotionDestMultScript).CheckInventoryforPotions(player)
		endif	
	elseif (akItemReference) && GetOwningQuest().getstage() > 10
		if(!GetOwningQuest().IsObjectiveDisplayed(40) && (akBaseItem as Potion))		
			(GetOwningQuest() as _M_QuestGatherPotionDestMultScript).PotionAdded(akBaseItem as Potion, akItemReference as ObjectReference)
		endIf
	endif	
endEvent


Event OnItemRemoved(Form akBaseItem, int aiItemCount, ObjectReference akItemReference, ObjectReference akDestContainer)

	if(GetOwningQuest().getstage() > 10 && (akBaseItem as Potion) && akItemReference)
		(GetOwningQuest() as _M_QuestGatherPotionDestMultScript).PotionRemoved(akBaseItem as Potion, akItemReference as ObjectReference)
	endIf
endEvent

Event OnItemCrafted(ObjectReference akBench, Location akLocation, Form akCreatedItem)

	if (akCreatedItem as Potion) && GetOwningQuest().getstage() > 10
		if !GetOwningQuest().IsObjectiveDisplayed(40)
			Actor player = Game.GetPlayer()
			(GetOwningQuest() as _M_QuestGatherPotionDestMultScript).CheckInventoryforPotions(player)
		endif
	endif
	
EndEvent

Function shutdownScript(Int currentVersion, Int nevVersion)
    UnregisterForAllMenus()
	PO3_Events_Alias.UnRegisterForItemCrafted(self)
EndFunction