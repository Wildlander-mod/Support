scriptName _M_GGMCM extends MCM_ConfigBase

;-- Properties --------------------------------------

GlobalVariable Property _M_GlobalRewardCourierMealLow Auto
GlobalVariable Property _M_GlobalRewardGatherMeal Auto
GlobalVariable Property _M_GlobalRewardGatherCookedFood Auto
GlobalVariable Property _M_GlobalRewardGatherDrinks Auto
GlobalVariable Property _M_GlobalRewardGatherBookLow Auto
GlobalVariable Property _M_GlobalRewardClearDraugr Auto
GlobalVariable Property _M_GlobalRewardGatherArmorSols Auto
GlobalVariable Property _M_GlobalRewardGatherArmorPreCW Auto
GlobalVariable Property _M_GlobalRewardGatherArmorPostCW Auto
GlobalVariable Property _M_GlobalRewardGatherSmithLow Auto
GlobalVariable Property _M_GlobalRewardGatherSmithHigh Auto

GlobalVariable Property _M_GlobalRewardGatherWizardClothing Auto
GlobalVariable Property _M_GlobalRewardGatherNobleClothing Auto
GlobalVariable Property _M_GlobalRewardGatherCommonClothing Auto

GlobalVariable Property _M_GlobalRewardGatherPeltMed Auto
GlobalVariable Property _M_GlobalRewardGatherPeltLow Auto
GlobalVariable Property _M_GlobalRewardGatherPeltHigh Auto

GlobalVariable Property _M_GlobalRewardGatherSpellTome Auto
GlobalVariable Property _M_GlobalRewardGatherSpellSolution Auto
GlobalVariable Property _M_GlobalRewardGatherSpellScroll Auto 

GlobalVariable Property _M_GlobalRewardGatherVeggies Auto
GlobalVariable Property _M_GlobalRewardGatherFish Auto

GlobalVariable Property _M_GlobalRewardTemper Auto
GlobalVariable Property _M_GlobalRewardShoppingList Auto
GlobalVariable Property _M_GlobalRewardRestock Auto
GlobalVariable Property _M_GlobalRewardAlchemy Auto

GlobalVariable Property _M_GlobalRewardClearMage Auto 
GlobalVariable Property _M_GlobalRewardCourierHarvestFar Auto
GlobalVariable Property _M_GlobalRewardCourierHarvestMed Auto
GlobalVariable Property _M_GlobalRewardCourierHarvestNear Auto
GlobalVariable Property _M_GlobalRewardGatherGemstoneHigh Auto
GlobalVariable Property _M_GlobalRewardGatherGemstoneLow Auto
GlobalVariable Property _M_GlobalRewardGatherGemstoneMed Auto
GlobalVariable Property _M_GlobalRewardGatherWood Auto


;-- Variables ---------------------------------------
Bool migrated = false

;-- Functions ---------------------------------------

; Skipped compiler generated GetState

function Default()

	self.SetModSettingInt("iRewardCourierMeal:CourierQuests", 25)
	self.SetModSettingInt("iEasyPeltGatheringReward:GatheringQuests", 100)
	self.SetModSettingInt("iNormalPeltGatheringReward:GatheringQuests", 475)
	self.SetModSettingInt("iHardPeltGatheringReward:GatheringQuests", 600)
	self.SetModSettingInt("iShoppingGatheringReward:GatheringQuests", 25)
	
	self.SetModSettingInt("iArmorPreCWGatheringReward:CraftingQuests", 75)
	self.SetModSettingInt("iArmorPostCWGatheringReward:CraftingQuests", 75)
	self.SetModSettingInt("iArmorSolsGatheringReward:CraftingQuests", 150)
	self.SetModSettingInt("iSmithLowGatheringReward:CraftingQuests", 75)
	self.SetModSettingInt("iSmithHighGatheringReward:CraftingQuests", 150)
	self.SetModSettingInt("iWizardGatheringReward:CraftingQuests", 250)
	self.SetModSettingInt("iCommonGatheringReward:CraftingQuests", 75)
	self.SetModSettingInt("iNobleGatheringReward:CraftingQuests", 150)
	self.SetModSettingInt("iTemperGatheringReward:CraftingQuests", 55)
	self.SetModSettingInt("iPotionGatheringReward:CraftingQuests", 25)
	
	self.SetModSettingInt("iMealGatheringReward:CookingQuests", 250)
	self.SetModSettingInt("iCookedGatheringReward:CookingQuests", 75)
	self.SetModSettingInt("iDrinksGatheringReward:CookingQuests", 150)
	self.SetModSettingInt("iFishGatheringReward:CookingQuests", 150)
	self.SetModSettingInt("iVeggiesGatheringReward:CookingQuests", 75)
	self.SetModSettingInt("iScrollGatheringReward:SpellResearchQuests", 75)
	self.SetModSettingInt("iTomeGatheringReward:SpellResearchQuests", 150)
	self.SetModSettingInt("iSolutionGatheringReward:SpellResearchQuests", 250)
	self.SetModSettingInt("iDraugrBountyReward:BountyQuests", 500)
	self.SetModSettingInt("iBookRetrievalReward:RetrieveQuests", 100)
	
	self.SetModSettingInt("iRewardCourierHarvestNear:CourierQuests", 50)
	self.SetModSettingInt("iRewardCourierHarvestMed:CourierQuests", 100)
	self.SetModSettingInt("iRewardCourierHarvestFar:CourierQuests", 150)
	self.SetModSettingInt("iGatherGemstoneLow:GatheringQuests",100 )
	self.SetModSettingInt("iGatherGemstoneMed:GatheringQuests", 475)
	self.SetModSettingInt("iGatherGemstoneHigh:GatheringQuests", 600)
	self.SetModSettingInt("iGatherWood:GatheringQuests", 50)
	self.SetModSettingInt("iMageBountyReward:BountyQuests", 500)
	self.SetModSettingInt("iRestockGatheringReward:GatheringQuests",100)
	

	self.SetModSettingBool("bEnabled:Maintenance", true)
	self.SetModSettingInt("iLoadingDelay:Maintenance", 0)
	self.SetModSettingBool("bLoadSettingsonReload:Maintenance", false)
	self.SetModSettingBool("bVerbose:Maintenance", false)
	self.VerboseMessage("[Missives for the Good Guys] Settings reset!")
	self.Load()
endFunction

function OnPageSelect(String a_page)

	parent.OnPageSelect(a_page)
endFunction

function MigrateToMCMHelper()

	self.SetModSettingInt("iRewardCourierMeal:CourierQuests", _M_GlobalRewardCourierMealLow.GetValue() as Int)
	self.SetModSettingInt("iEasyPeltGatheringReward:GatheringQuests", _M_GlobalRewardGatherPeltLow.GetValue() as Int)
	self.SetModSettingInt("iNormalPeltGatheringReward:GatheringQuests", _M_GlobalRewardGatherPeltMed.GetValue() as Int)
	self.SetModSettingInt("iHardPeltGatheringReward:GatheringQuests", _M_GlobalRewardGatherPeltHigh.GetValue() as Int)
	
	self.SetModSettingInt("iArmorPreCWGatheringReward:CraftingQuests", _M_GlobalRewardGatherArmorPreCW.GetValue() as Int)
	self.SetModSettingInt("iArmorPostCWGatheringReward:CraftingQuests", _M_GlobalRewardGatherArmorPostCW.GetValue() as Int)
	self.SetModSettingInt("iArmorSolsGatheringReward:CraftingQuests", _M_GlobalRewardGatherArmorSols.GetValue() as Int)
	self.SetModSettingInt("iSmithLowGatheringReward:CraftingQuests", _M_GlobalRewardGatherSmithLow.GetValue() as Int)
	self.SetModSettingInt("iSmithHighGatheringReward:CraftingQuests", _M_GlobalRewardGatherSmithHigh.GetValue() as Int)
	
	self.SetModSettingInt("iWizardGatheringReward:CraftingQuests", _M_GlobalRewardGatherWizardClothing.GetValue() as Int)
	self.SetModSettingInt("iCommonGatheringReward:CraftingQuests", _M_GlobalRewardGatherCommonClothing.GetValue() as Int)
	self.SetModSettingInt("iNobleGatheringReward:CraftingQuests", _M_GlobalRewardGatherNobleClothing.GetValue() as Int)
	
	self.SetModSettingInt("iMealGatheringReward:CookingQuests", _M_GlobalRewardGatherMeal.GetValue() as Int)
	self.SetModSettingInt("iCookedGatheringReward:CookingQuests", _M_GlobalRewardGatherCookedFood.GetValue() as Int)
	self.SetModSettingInt("iDrinksGatheringReward:CookingQuests", _M_GlobalRewardGatherDrinks.GetValue() as Int)
	self.SetModSettingInt("iFishGatheringReward:CookingQuests", _M_GlobalRewardGatherFish.GetValue() as Int)
	self.SetModSettingInt("iVeggiesGatheringReward:CookingQuests", _M_GlobalRewardGatherVeggies.GetValue() as Int)

	self.SetModSettingInt("iScrollGatheringReward:SpellResearchQuests", _M_GlobalRewardGatherSpellScroll.GetValue() as Int)
	self.SetModSettingInt("iTomeGatheringReward:SpellResearchQuests", _M_GlobalRewardGatherSpellTome.GetValue() as Int)
	self.SetModSettingInt("iSolutionGatheringReward:SpellResearchQuests", _M_GlobalRewardGatherSpellSolution.GetValue() as Int)
	
	self.SetModSettingInt("iDraugrBountyReward:BountyQuests", _M_GlobalRewardClearDraugr.GetValue() as Int)
	self.SetModSettingInt("iBookRetrievalReward:RetrieveQuests", _M_GlobalRewardGatherBookLow.GetValue() as Int)
	
	self.SetModSettingInt("iTemperGatheringReward:BountyQuests", _M_GlobalRewardTemper.GetValue() as Int)
	self.SetModSettingInt("iShoppingGatheringReward:GatheringQuests", _M_GlobalRewardShoppingList.GetValue() as Int)
	self.SetModSettingInt("iRestockGatheringReward:GatheringQuests", _M_GlobalRewardRestock.GetValue() as Int)
	self.SetModSettingInt("iPotionGatheringReward:CraftingQuests", _M_GlobalRewardAlchemy.GetValue() as Int)
	
	
	self.SetModSettingInt("iMageBountyReward:BountyQuests", 	_M_GlobalRewardClearMage.GetValue() as Int) 
	self.SetModSettingInt("iRewardCourierHarvestFar:CourierQuests", 	_M_GlobalRewardCourierHarvestFar.GetValue() as Int)
	self.SetModSettingInt("iRewardCourierHarvestMed:CourierQuests", 	_M_GlobalRewardCourierHarvestMed.GetValue() as Int)
	self.SetModSettingInt("iRewardCourierHarvestNear:CourierQuests", 	_M_GlobalRewardCourierHarvestNear.GetValue() as Int)
	self.SetModSettingInt("iGatherGemstoneHigh:GatheringQuests", 	_M_GlobalRewardGatherGemstoneHigh.GetValue() as Int)
	self.SetModSettingInt("iGatherGemstoneLow:GatheringQuests", 	_M_GlobalRewardGatherGemstoneLow.GetValue() as Int)
	self.SetModSettingInt("iGatherGemstoneMed:GatheringQuests", 	_M_GlobalRewardGatherGemstoneMed.GetValue() as Int)
	self.SetModSettingInt("iGatherWood:GatheringQuests", 	_M_GlobalRewardGatherWood.GetValue() as Int)


endFunction

function VerboseMessage(String m)

	if self.GetModSettingBool("bVerbose:Maintenance")
		debug.Notification(m)
	endIf
endFunction

function OnConfigOpen()

	parent.OnConfigOpen()
	if !migrated
		self.MigrateToMCMHelper()
		migrated = true
		self.VerboseMessage("[Missives For the Good Guys] OnConfigOpen: Settings imported!")
	endIf
endFunction

function Load()

	_M_GlobalRewardGatherBookLow.SetValue(self.GetModSettingInt("iBookRetrievalReward:RetrieveQuests") as Float)
	_M_GlobalRewardClearDraugr.SetValue(self.GetModSettingInt("iDraugrBountyReward:BountyQuests") as Float)
	
	_M_GlobalRewardGatherSpellScroll.SetValue(self.GetModSettingInt("iScrollGatheringReward:SpellResearchQuests") as Float)
	_M_GlobalRewardGatherSpellTome.SetValue(self.GetModSettingInt("iTomeGatheringReward:SpellResearchQuests") as Float)
	_M_GlobalRewardGatherSpellSolution.SetValue(self.GetModSettingInt("iSolutionGatheringReward:SpellResearchQuests") as Float)
	
	_M_GlobalRewardGatherMeal.SetValue(self.GetModSettingInt("iMealGatheringReward:CookingQuests") as Float)
	_M_GlobalRewardGatherCookedFood.SetValue(self.GetModSettingInt("iCookedGatheringReward:CookingQuests") as Float)
	_M_GlobalRewardGatherDrinks.SetValue(self.GetModSettingInt("iDrinksGatheringReward:CookingQuests") as Float)
	_M_GlobalRewardGatherFish.SetValue(self.GetModSettingInt("iFishGatheringReward:CookingQuests") as Float)
	_M_GlobalRewardGatherVeggies.SetValue(self.GetModSettingInt("iVeggiesGatheringReward:CookingQuests") as Float)
	
	_M_GlobalRewardGatherWizardClothing.SetValue(self.GetModSettingInt("iWizardGatheringReward:CraftingQuests") as Float)
	_M_GlobalRewardGatherCommonClothing.SetValue(self.GetModSettingInt("iCommonGatheringReward:CraftingQuests") as Float)
	_M_GlobalRewardGatherNobleClothing.SetValue(self.GetModSettingInt("iNobleGatheringReward:CraftingQuests") as Float)
	
	_M_GlobalRewardGatherSmithHigh.SetValue(self.GetModSettingInt("iSmithHighGatheringReward:CraftingQuests") as Float)
	_M_GlobalRewardGatherSmithLow.SetValue(self.GetModSettingInt("iSmithLowGatheringReward:CraftingQuests") as Float)
	_M_GlobalRewardGatherArmorSols.SetValue(self.GetModSettingInt("iArmorSolsGatheringReward:CraftingQuests") as Float)
	_M_GlobalRewardGatherArmorPostCW.SetValue(self.GetModSettingInt("iArmorPostCWGatheringReward:CraftingQuests") as Float)
	_M_GlobalRewardGatherArmorPreCW.SetValue(self.GetModSettingInt("iArmorPreCWGatheringReward:CraftingQuests") as Float)
	
	_M_GlobalRewardGatherPeltHigh.SetValue(self.GetModSettingInt("iHardPeltGatheringReward:GatheringQuests") as Float)
	_M_GlobalRewardGatherPeltMed.SetValue(self.GetModSettingInt("iNormalPeltGatheringReward:GatheringQuests") as Float)
	_M_GlobalRewardGatherPeltLow.SetValue(self.GetModSettingInt("iEasyPeltGatheringReward:GatheringQuests") as Float)
	_M_GlobalRewardCourierMealLow.SetValue(self.GetModSettingInt("iRewardCourierMeal:CourierQuests") as Float)
	
	
	_M_GlobalRewardTemper.SetValue(self.GetModSettingInt("iTemperGatheringReward:GatheringQuests") as Float)
	_M_GlobalRewardShoppingList.SetValue(self.GetModSettingInt("iShoppingGatheringReward:GatheringQuests") as Float)
	_M_GlobalRewardRestock.SetValue(self.GetModSettingInt("iRestockGatheringReward:GatheringQuests") as Float)
	_M_GlobalRewardAlchemy.SetValue(self.GetModSettingInt("iPotionGatheringReward:CraftingQuests") as Float)
	
	_M_GlobalRewardClearMage.SetValue(self.GetModSettingInt("iMageBountyReward:BountyQuests") as Float)
	_M_GlobalRewardCourierHarvestFar.SetValue(self.GetModSettingInt("iRewardCourierHarvestFar:CourierQuests") as Float)
	_M_GlobalRewardCourierHarvestMed.SetValue(self.GetModSettingInt("iRewardCourierHarvestMed:CourierQuests") as Float)
	_M_GlobalRewardCourierHarvestNear.SetValue(self.GetModSettingInt("iRewardCourierHarvestNear:CourierQuests") as Float)
	_M_GlobalRewardGatherGemstoneHigh.SetValue(self.GetModSettingInt("iGatherGemstoneHigh:GatheringQuests") as Float)
	_M_GlobalRewardGatherGemstoneLow.SetValue(self.GetModSettingInt("iGatherGemstoneLow:GatheringQuests") as Float)
	_M_GlobalRewardGatherGemstoneMed.SetValue(self.GetModSettingInt("iGatherGemstoneMed:GatheringQuests") as Float)
	_M_GlobalRewardGatherWood.SetValue(self.GetModSettingInt("iGatherWood:GatheringQuests") as Float)

	
	self.VerboseMessage("[Missives For the Good Guys] Settings applied!")
endFunction

function OnUpdate()

	parent.OnUpdate()
	if !migrated
		self.MigrateToMCMHelper()
		migrated = true
		self.VerboseMessage("[Missives For the Good Guys] OnUpdate: Settings imported!")
	endIf
endFunction

function OnGameReload()

	parent.OnGameReload()
	if !migrated
		self.MigrateToMCMHelper()
		migrated = true
		self.VerboseMessage("[Missives For the Good Guys] OnGameReload: Settings imported!")
	endIf
	if self.GetModSettingBool("bLoadSettingsonReload:Maintenance")
		self.LoadSettings()
		self.VerboseMessage("[Missives For the Good Guys] OnGameReload: Settings autoloaded!")
	endIf
endFunction

; Skipped compiler generated GotoState

function LoadSettings()

	if self.GetModSettingBool("bEnabled:Maintenance") == false
		return 
	endIf
	utility.Wait(self.GetModSettingInt("iLoadingDelay:Maintenance") as Float)
	self.VerboseMessage("[Missives For the Good Guys] Settings autoloaded!")
	self.Load()
endFunction

function OnConfigInit()

	parent.OnConfigInit()
	migrated = true
	self.LoadSettings()
endFunction

Int function GetVersion()

	return 1
endFunction

function OnSettingChange(String a_ID)

	parent.OnSettingChange(a_ID)
	if a_ID == "iRewardCourierMeal:CourierQuests"
		_M_GlobalRewardCourierMealLow.SetValue(self.GetModSettingInt("iRewardCourierMeal:CourierQuests") as Float)
	elseIf a_ID == "iHardPeltGatheringReward:GatheringQuests"
		_M_GlobalRewardGatherPeltHigh.SetValue(self.GetModSettingInt("iHardPeltGatheringReward:GatheringQuests") as Float)
	elseIf a_ID == "iNormalPeltGatheringReward:GatheringQuests"
		_M_GlobalRewardGatherPeltMed.SetValue(self.GetModSettingInt("iNormalPeltGatheringReward:GatheringQuests") as Float)
	elseIf a_ID == "iEasyPeltGatheringReward:GatheringQuests"
		_M_GlobalRewardGatherPeltLow.SetValue(self.GetModSettingInt("iEasyPeltGatheringReward:GatheringQuests") as Float)		
	elseIf a_ID == "iSmithHighGatheringReward:CraftingQuests"
		_M_GlobalRewardGatherSmithHigh.SetValue(self.GetModSettingInt("iSmithHighGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iSmithLowGatheringReward:CraftingQuests"
		_M_GlobalRewardGatherSmithLow.SetValue(self.GetModSettingInt("iSmithLowGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iArmorSolsGatheringReward:CraftingQuests"
		_M_GlobalRewardGatherArmorSols.SetValue(self.GetModSettingInt("iArmorSolsGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iArmorPostCWGatheringReward:CraftingQuests"
		_M_GlobalRewardGatherArmorPostCW.SetValue(self.GetModSettingInt("iArmorPostCWGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iArmorPreCWGatheringReward:CraftingQuests"
		_M_GlobalRewardGatherArmorPreCW.SetValue(self.GetModSettingInt("iArmorPreCWGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iWizardGatheringReward:CraftingQuests"
		_M_GlobalRewardGatherWizardClothing.SetValue(self.GetModSettingInt("iWizardGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iCommonGatheringReward:CraftingQuests"
		_M_GlobalRewardGatherCommonClothing.SetValue(self.GetModSettingInt("iCommonGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iNobleGatheringReward:CraftingQuests"
		_M_GlobalRewardGatherNobleClothing.SetValue(self.GetModSettingInt("iNobleGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iVeggiesGatheringReward:CookingQuests"
		_M_GlobalRewardGatherVeggies.SetValue(self.GetModSettingInt("iVeggiesGatheringReward:CookingQuests") as Float)
	elseIf a_ID == "iFishGatheringReward:CookingQuests"
		_M_GlobalRewardGatherFish.SetValue(self.GetModSettingInt("iFishGatheringReward:CookingQuests") as Float)
	elseIf a_ID == "iDrinksGatheringReward:CookingQuests"
		_M_GlobalRewardGatherDrinks.SetValue(self.GetModSettingInt("iDrinksGatheringReward:CookingQuests") as Float)
	elseIf a_ID == "iCookedGatheringReward:CookingQuests"
		_M_GlobalRewardGatherFish.SetValue(self.GetModSettingInt("iCookedGatheringReward:CookingQuests") as Float)	
	elseIf a_ID == "iMealGatheringReward:CookingQuests"
		_M_GlobalRewardGatherMeal.SetValue(self.GetModSettingInt("iMealGatheringReward:CookingQuests") as Float)	
	elseIf a_ID == "iScrollGatheringReward:SpellResearchQuests"
		_M_GlobalRewardGatherSpellScroll.SetValue(self.GetModSettingInt("iScrollGatheringReward:SpellResearchQuests") as Float)
	elseIf a_ID == "iTomeGatheringReward:SpellResearchQuests"
		_M_GlobalRewardGatherSpellTome.SetValue(self.GetModSettingInt("iTomeGatheringReward:SpellResearchQuests") as Float)
	elseIf a_ID == "iSolutionGatheringReward:SpellResearchQuests"
		_M_GlobalRewardGatherSpellSolution.SetValue(self.GetModSettingInt("iSolutionGatheringReward:SpellResearchQuests") as Float)
	elseIf a_ID == "iBookRetrievalReward:RetrieveQuests"
		_M_GlobalRewardGatherBookLow.SetValue(self.GetModSettingInt("iBookRetrievalReward:RetrieveQuests") as Float)
	elseIf a_ID == "iDraugrBountyReward:BountyQuests"
		_M_GlobalRewardClearDraugr.SetValue(self.GetModSettingInt("iDraugrBountyReward:BountyQuests") as Float)
	elseIf a_ID == "iTemperGatheringReward:CraftingQuests"
		_M_GlobalRewardTemper.SetValue(self.GetModSettingInt("iTemperGatheringReward:CraftingQuests") as Float)
	elseIf a_ID == "iShoppingGatheringReward:GatheringQuests"
		_M_GlobalRewardShoppingList.SetValue(self.GetModSettingInt("iShoppingGatheringReward:GatheringQuests") as Float)
	elseIf a_ID == "iRestockGatheringReward:GatheringQuests"
		_M_GlobalRewardRestock.SetValue(self.GetModSettingInt("iRestockGatheringReward:GatheringQuests") as Float)
	elseIf a_ID == "iPotionGatheringReward:CraftingQuests"
		_M_GlobalRewardAlchemy.SetValue(self.GetModSettingInt("iPotionGatheringReward:CraftingQuests") as Float)	
	elseIf a_ID == "iMageBountyReward:BountyQuests"	
		_M_GlobalRewardClearMage.SetValue(self.GetModSettingInt("iMageBountyReward:BountyQuests") as Float)
	elseIf a_ID == "iRewardCourierHarvestFar:CourierQuests"	
		_M_GlobalRewardCourierHarvestFar.SetValue(self.GetModSettingInt("iRewardCourierHarvestFar:CourierQuests") as Float)
	elseIf a_ID == "iRewardCourierHarvestMed:CourierQuests"
		_M_GlobalRewardCourierHarvestMed.SetValue(self.GetModSettingInt("iRewardCourierHarvestMed:CourierQuests") as Float)
	elseIf a_ID == "iRewardCourierHarvestNear:CourierQuests"
		_M_GlobalRewardCourierHarvestNear.SetValue(self.GetModSettingInt("iRewardCourierHarvestNear:CourierQuests") as Float)
	elseIf a_ID == "iGatherGemstoneHigh:GatheringQuests"
		_M_GlobalRewardGatherGemstoneHigh.SetValue(self.GetModSettingInt("iGatherGemstoneHigh:GatheringQuests") as Float)
	elseIf a_ID == "iGatherGemstoneLow:GatheringQuests"
		_M_GlobalRewardGatherGemstoneLow.SetValue(self.GetModSettingInt("iGatherGemstoneLow:GatheringQuests") as Float)
	elseIf a_ID == "iGatherGemstoneMed:GatheringQuests"
		_M_GlobalRewardGatherGemstoneMed.SetValue(self.GetModSettingInt("iGatherGemstoneMed:GatheringQuests") as Float)
	elseIf a_ID == "iGatherWood:GatheringQuests"	
		_M_GlobalRewardGatherWood.SetValue(self.GetModSettingInt("iGatherWood:GatheringQuests") as Float)
		
		
		
	endIf

endFunction

