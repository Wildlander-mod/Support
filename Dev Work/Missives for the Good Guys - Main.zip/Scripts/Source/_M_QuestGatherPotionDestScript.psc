;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 11
Scriptname _M_QuestGatherPotionDestScript Extends Quest Hidden

import _m_MissivesUtils

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY    

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Potion
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Potion Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

import PO3_SKSEFunctions

Event OnInit()
    ; Try to get the GlobalVariable from Requiem.esp
     GlobalVariable tempVar = Game.GetFormFromFile(0xAD3A1B, "Requiem.esp") as GlobalVariable
    
    if tempVar != None
        REQ_Internal_Player_Is_In_Training = tempVar
    else
        Debug.Trace("Requiem.esp is NOT in the load order. Using default behavior.")
    endif
	

	keyword MissiveSettlement = Game.GetFormFromFile(0xF40, "MissivesfortheGoodGuys.esp") as keyword
	
	if !Alias_Destination

		if Alias_QuestGiver
			Location npcLoc    = Alias_QuestGiver.getRef().GetCurrentLocation()
			
			if npcLoc != None && npcLoc.HasKeyword(MissiveSettlement)
				Alias_Destination.ForceLocationTo(npcLoc)
			else	
				Location parentLoc = GetParentLocation(npcLoc)
				
				if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
					Alias_Destination.ForceLocationTo(parentLoc)
				else
					parentLoc = GetParentLocation(parentLoc)
					
					if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
						Alias_Destination.ForceLocationTo(parentLoc)
					endif	
				endif			
			endif
		endIf
	endif
EndEvent

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
	
SetObjectiveDisplayed(20)
Actor player = Game.GetPlayer()

CheckInventoryforPotions(player)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
	CompleteAllObjectives()

	int RewardValue = Alias_Potion.GetRef().GetBaseObject().getGoldValue() 

	RewardValue = RewardValue + GoldReward.GetValue() as int

	Game.GetPlayer().RemoveItem(Alias_Potion.GetRef().GetBaseObject())
	Game.GetPlayer().AddItem(Gold001, RewardValue)
	Game.GetPlayer().AddItem(Reward)

	REQ_Internal_Player_Is_In_Training.SetValueInt(1)

	ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByID(16)
	
	Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() ; From Skyrim Skill Leveling Function: xp = level ^ 1.95 * mult + offset
	
	if Skill.GetCurrentValue(game.getplayer()) < 81 
		game.AdvanceSkill("Alchemy", xpRequired)
	endif

	REQ_Internal_Player_Is_In_Training.SetValueInt(0)

SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_13
Function Fragment_13()

;BEGIN CODE

	;Debug.Trace("Stage 5: Missive Setup - Select effect")													  
	Maintenance()

	
;END CODE
EndFunction  
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment


Function PotionAdded(potion Potionbase, Objectreference akItemReference)

	bool IsRequiredPotion
	bool notusedbycurrentquest 
	
	If GetStage() == 20 
	
		if IsObjectiveDisplayed(20)  && akItemReference.GetNumReferenceAliases() > 0 
			;Can't use this one is already attached to quest objectives
			notusedbycurrentquest = true
		endif

		if !notusedbycurrentquest
			IsRequiredPotion = _m_MissivesUtils.isPotionofType( Potionbase,  PotionEffect )
				
			if IsRequiredPotion && !IsObjectiveDisplayed(40)
				SetObjectiveCompleted(20)
				SetObjectiveDisplayed(40, true, true)
				Alias_Potion.ForceRefTo(akItemReference)
				_m_Global_AlchemyCount.setvalue(1)
				UpdateCurrentInstanceGlobal(_m_Global_AlchemyCount)
			endIf
		ENDIF 
	endif

endFunction

Function PotionRemoved(potion Potionbase, ObjectReference akItemReference)

	if IsObjectiveDisplayed(40)	
		bool IsRequiredPotion

		IsRequiredPotion = _m_MissivesUtils.isPotionofType( Potionbase,  PotionEffect )
				
		if IsRequiredPotion && akItemReference == Alias_Potion.GetRef()

			ObjectReference  Defaultpotion = Game.GetFormFromFile(0x9E4, "MissivesSharedResources.Esp") as ObjectReference 

			Alias_Potion.ForceRefTo(Defaultpotion)

			Potion baseObj = akItemReference.GetBaseObject() as potion
			
			if baseObj
				akItemReference.SetName(baseObj.GetName())
			endif
		
			SetObjectiveDisplayed(40, false)
			
			CheckInventoryforPotions(Game.GetPlayer())
		
			if !IsObjectiveDisplayed(40)	
				SetObjectiveCompleted(20, false)
				SetObjectiveDisplayed(20, true, true)
				_m_Global_AlchemyCount.setvalue(0)
				UpdateCurrentInstanceGlobal(_m_Global_AlchemyCount)

			endif
		endIf
	endif


endFunction

Function RecheckInventory(form itemToDrop)

	; Need to Drop & Pickup this to detect each potion - So we remove it , then add it back to player's inventory to trigger "on item added"
	
	If GetStage() == 20 
		Actor player = Game.GetPlayer()
		
		bool IsRequiredPotion = _m_MissivesUtils.isPotionofType(itemToDrop as Potion,  PotionEffect )

		if IsRequiredPotion
			DropAllOfItem(player, itemToDrop, QContainer, 1)
		endif
	endif 
EndFunction

function CheckInventoryforPotions(Actor player)

If GetStage() == 20 
	Form[] Forms = player.GetContainerForms() 
	Int L = Forms.Length 
	Int iIndex = 0 
	While iIndex < L 
		Form kItem = Forms[iIndex]
		if (kItem as Potion) 
			bool IsRequiredPotion = isPotionofType( kItem as Potion,  PotionEffect )
			
			if IsRequiredPotion
				RecheckInventory(kItem)
			endif
		endif

		iIndex += 1 
		
		if getstage() == 40 
			iIndex = L
		endif 
		
	EndWhile
endif 

endFunction

Function Maintenance()
    ; This code runs every time the game is loaded
	
	Potion ItemBase = Alias_Item.GetRef().GetBaseObject() as Potion

	PotionEffect = ItemBase.GetNthEffectMagicEffect(0)

	_m_ItemName.setName("Potion with the effect of " + PotionEffect.getname()) 
	
	String PotionName = PotionEffect.getname()
	int count = 1
	
	UpdateBookTitlePotion(count, PotionName, M_message, Alias_Destination)
EndFunction

ObjectReference SelectedPotion

MagicEffect PotionEffect    

Message property _m_ItemName Auto

globalvariable property REQ_Internal_Player_Is_In_Training auto

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

GlobalVariable Property _m_Global_AlchemyCount   Auto  

LeveledItem Property Reward  Auto  

ObjectReference Property QContainer Auto

Message property m_Message Auto