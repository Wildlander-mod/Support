Scriptname _M_ReadNoteScript extends ReferenceAlias

Event OnRead()
	Quest q = GetOwningQuest()
	If q.GetStage() < 50
		q.SetStage(50)
	EndIf
EndEvent

