ScriptName _m_ReloadMessagesDest extends ReferenceAlias
 
Event OnPlayerLoadGame()

	(GetOwningQuest() as _M_QuestGatherPotionDestScript).Maintenance()
EndEvent