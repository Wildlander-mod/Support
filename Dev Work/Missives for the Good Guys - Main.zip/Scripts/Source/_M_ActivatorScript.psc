Scriptname _M_ActivatorScript extends ObjectReference

GlobalVariable Property QuestChanceLow Auto
GlobalVariable Property QuestChanceMed Auto
GlobalVariable Property QuestChanceHigh Auto
GlobalVariable Property QuestChanceVeryHigh Auto

FormList Property QuestsLow Auto
FormList Property QuestsMed Auto
FormList Property QuestsHigh Auto
FormList Property QuestsVeryHigh Auto

GlobalVariable Property GameDaysPassed Auto
GlobalVariable Property RefreshRate Auto

ObjectReference Property MissiveBoard Auto

float LastUpdate = -100.0
Int RefreshInProgress = 0
bool Debugmessages = true

Event OnTriggerEnter(ObjectReference akActionRef)
    if RefreshInProgress == 1
        return
    endif

    INT TOTALQUESTS = QuestsLow.GetSize() + QuestsMed.GetSize() + QuestsHigh.GetSize() + QuestsVeryHigh.GetSize()
    if TOTALQUESTS > 0

        if MissiveBoard.GetNumItems() == 0
            LastUpdate = -100.0
        endif

        float currentGameDaysPassed = GameDaysPassed.GetValue()
        float lastRefreshRate = RefreshRate.GetValue()

        if akActionRef == Game.GetPlayer() && (currentGameDaysPassed > LastUpdate + lastRefreshRate)
		    Debug.Trace("Missives: Board: " + MissiveBoard + " Quests to load: " + TOTALQUESTS)
            Debug.Trace("Missives: Starting Refresh")

            LastUpdate = currentGameDaysPassed
            RefreshInProgress = 1

            MissiveBoard.BlockActivation(true)

            UpdateQuests(QuestChanceLow.GetValue(), QuestsLow)
            UpdateQuests(QuestChanceMed.GetValue(), QuestsMed)
            UpdateQuests(QuestChanceHigh.GetValue(), QuestsHigh)
            UpdateQuests(QuestChanceVeryHigh.GetValue(), QuestsVeryHigh)

            Utility.Wait(1)

            MissiveBoard.BlockActivation(false)
            RefreshInProgress = 0
            Debug.Trace("Missives: Quests Updated")
        endif
    endif
endEvent

Function UpdateQuests(float QuestChance, FormList QuestList)
    int QuestIndex = 0
    ReferenceAlias nthAlias

    while QuestIndex < QuestList.GetSize()
        Quest MissiveQuest = QuestList.GetAt(QuestIndex) as Quest
		
        ReferenceAlias QuestBoardAlias = MissiveQuest.GetAliasByName("MissiveBoard") as ReferenceAlias
		
		if QuestBoardAlias == None
			if Utility.RandomInt(0, 100) <= QuestChance 
				if !MissiveQuest.IsRunning()
					StartQuestWithRetries(MissiveQuest)
				elseif MissiveQuest.GetStage() == 0
					ResetQuest(MissiveQuest)
				endif
			else
				if MissiveQuest.GetStage() == 0 
					MissiveQuest.SetStage(110)
					MissiveQuest.Reset()
				endif
			endif
		else
			ObjectReference QuestBoard = QuestBoardAlias.GetReference() as ObjectReference

			if Utility.RandomInt(0, 100) <= QuestChance 
				if !MissiveQuest.IsRunning()
					StartQuestWithRetries(MissiveQuest)
				elseif MissiveQuest.GetStage() == 0 && QuestBoard == MissiveBoard
					ResetQuest(MissiveQuest)
				endif
			else
				if MissiveQuest.GetStage() == 0 && QuestBoard == MissiveBoard
					MissiveQuest.SetStage(110)
					MissiveQuest.Reset()
				endif
			endif
		endif

        QuestIndex += 1
    endWhile
endFunction

Function StartQuestWithRetries(Quest MissiveQuest)
	int retries = 0
	bool allAliasesValid = false

	while retries < 5 && !allAliasesValid
		if retries > 0
			MissiveQuest.SetStage(110)
		endif

		bool started = MissiveQuest.Start()
		
		if !started
			if Debugmessages
				Debug.Trace("Missives: Failed to start quest  Retry #" + retries + " - Resetting quest: " + MissiveQuest)
		    endif
			retries += 1
		else
			; Proceed with alias validation only if started
			allAliasesValid = true
			bool foundInvalid = false
			int idx = MissiveQuest.GetNumAliases()

			while idx > 0
				idx -= 1
				Alias baseAlias = MissiveQuest.GetNthAlias(idx)
				ReferenceAlias refAlias = baseAlias as ReferenceAlias
				LocationAlias locAlias = baseAlias as LocationAlias

				if baseAlias == None
					foundInvalid = true
				elseif refAlias
					if refAlias.GetReference() == None  && baseAlias.GetName() != "steward" 
						foundInvalid = true
					endif
				elseif locAlias
					if locAlias.GetLocation() == None
						foundInvalid = true
					endif
				endif
			endWhile

			if foundInvalid && Debugmessages
				allAliasesValid = false
				
				Debug.Trace("Missives: Alias validation failed. Reporting all aliases for quest: " + MissiveQuest)

				idx = MissiveQuest.GetNumAliases()
				while idx > 0
					idx -= 1
					Alias baseAlias = MissiveQuest.GetNthAlias(idx)
					ReferenceAlias refAlias = baseAlias as ReferenceAlias
					LocationAlias locAlias = baseAlias as LocationAlias

					if baseAlias == None
						Debug.Trace("Missives: Null Alias at index " + idx)
					elseif refAlias
						ObjectReference refObj = refAlias.GetReference()
						Debug.Trace("Missives: ReferenceAlias [" + refAlias.GetName() + "] = " + refObj)
					elseif locAlias
						Location loc = locAlias.GetLocation()
						Debug.Trace("Missives: LocationAlias [" + locAlias.GetName() + "] = " + loc)
					else
						Debug.Trace("Missives: Alias [" + baseAlias.GetName() + "] is not ReferenceAlias or LocationAlias")
					endif
				endWhile

				MissiveQuest.SetStage(110)
				retries += 1
			endif
		endif
	endWhile

	if !allAliasesValid
		Debug.Trace("Missives: Failed to initialize valid aliases after 5 attempts. Quest stopped: " + MissiveQuest)
	endif
EndFunction

Function ResetQuest(Quest MissiveQuest)
    MissiveQuest.SetStage(110)
    StartQuestWithRetries(MissiveQuest)
endFunction
