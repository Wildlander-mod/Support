;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 10
Scriptname _M_QuestShoppingListScript Extends Quest Hidden

;BEGIN ALIAS PROPERTY noteAlias
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_noteAlias Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY VegAlias
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_VegAlias Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY BakingAlias
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_BakingAlias Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY questGiverAlias
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_questGiverAlias Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY DrinksAlias
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_DrinksAlias Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MeatAlias
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MeatAlias Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY PlayerAlias
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_PlayerAlias Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY

import PO3_SKSEFunctions

Event OnInit()

	keyword MissiveSettlement = Game.GetFormFromFile(0xF40, "MissivesfortheGoodGuys.esp") as keyword
	
	if !Alias_Destination

		if Alias_questGiverAlias
			Location npcLoc    = Alias_questGiverAlias.getRef().GetCurrentLocation()
			
			if npcLoc != None && npcLoc.HasKeyword(MissiveSettlement)
				Alias_Destination.ForceLocationTo(npcLoc)
			else	
				Location parentLoc = GetParentLocation(npcLoc)
				
				if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
					Alias_Destination.ForceLocationTo(parentLoc)
				else
					parentLoc = GetParentLocation(parentLoc)
					
					if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
						Alias_Destination.ForceLocationTo(parentLoc)
					endif	
				endif			
			endif
		endIf
	endif	
	
	int count1 = Utility.RandomInt(ItemTotalMin.GetValue() as int, ItemTotalMax.GetValue() as int)
	int count2 = Utility.RandomInt(ItemTotalMin.GetValue() as int, ItemTotalMax.GetValue() as int)
	int count3 = Utility.RandomInt(ItemTotalMin.GetValue() as int, ItemTotalMax.GetValue() as int)
	int count4 = Utility.RandomInt(ItemTotalMin.GetValue() as int, ItemTotalMax.GetValue() as int)

	MissiveShoppingMeatGoal.SetValueInt(count1)
	MissiveShoppingBakingGoal.SetValueInt(count2)
	MissiveShoppingDrinksGoal.SetValueInt(count3)
	MissiveShoppingVegGoal.SetValueInt(count4)

	MissiveShoppingMeatCurrent.SetValueInt(0)
	MissiveShoppingBakingCurrent.SetValueInt(0)
	MissiveShoppingDrinksCurrent.SetValueInt(0)
	MissiveShoppingVegCurrent.SetValueInt(0)

	UpdateCurrentInstanceGlobal(MissiveShoppingMeatGoal)
	UpdateCurrentInstanceGlobal(MissiveShoppingBakingGoal)
	UpdateCurrentInstanceGlobal(MissiveShoppingDrinksGoal)
	UpdateCurrentInstanceGlobal(MissiveShoppingVegGoal)

	UpdateCurrentInstanceGlobal(MissiveShoppingMeatCurrent)
	UpdateCurrentInstanceGlobal(MissiveShoppingBakingCurrent)
	UpdateCurrentInstanceGlobal(MissiveShoppingDrinksCurrent)
	UpdateCurrentInstanceGlobal(MissiveShoppingVegCurrent)
	
EndEvent


;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE

SetObjectiveCompleted(20)
UpdateCount()
;END CODE
EndFunction
;END FRAGMENT


;BEGIN FRAGMENT Fragment_1
Function Fragment_1()
;BEGIN CODE

SetObjectiveDisplayed(20)

Game.GetPlayer().AddItem(Alias_noteAlias.GetRef())

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_8
Function Fragment_8()
;BEGIN CODE

; Debug.Trace("Stage 1: Missive Setup - setup filters")

If Alias_MeatAlias.GetRef()
	Form Meat   = Alias_MeatAlias.GetRef().GetBaseObject()
	Alias_PlayerAlias.AddInventoryEventFilter(Meat)
endIf

If Alias_BakingAlias.GetRef()
	Form Baking = Alias_BakingAlias.GetRef().GetBaseObject()
	Alias_PlayerAlias.AddInventoryEventFilter(Baking)	
endIf

If Alias_DrinksAlias.GetRef()
	Form Drinks = Alias_DrinksAlias.GetRef().GetBaseObject()
	Alias_PlayerAlias.AddInventoryEventFilter(Drinks)
endIf

If Alias_VegAlias.GetRef()
	Form Veg = Alias_VegAlias.GetRef().GetBaseObject()
	Alias_PlayerAlias.AddInventoryEventFilter(Veg)
endif

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE
	FailAllObjectives()
	SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE

; debug.trace("Shopping Drop Quest")
ObjectReference note = Alias_NoteAlias.GetRef()

PO3_SKSEFunctions.ClearReadFlag(Alias_NoteAlias.GetRef().GetBaseObject() as Book)

if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
	Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
	Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Player")
	Game.GetPlayer().RemoveItem(note, 1, true)
	PO3_SKSEFunctions.ClearReadFlag(note.GetBaseObject() as Book)
endIf

if(Game.GetPlayer().GetItemCount(note) > 0)
	Game.GetPlayer().RemoveItem(note, 1, true)
else	
	note.Delete()
endif

PO3_SKSEFunctions.ClearReadFlag(Alias_Missive.GetRef().GetBaseObject() as Book)

Stop()

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_3
Function Fragment_3()
;BEGIN CODE

SetObjectiveCompleted(20)
SetObjectiveCompleted(50)
SetObjectiveCompleted(51)
SetObjectiveDisplayed(60)

ObjectReference alias1 = Alias_MeatAlias.GetRef()
ObjectReference alias2 = Alias_BakingAlias.GetRef()
ObjectReference alias3 = Alias_DrinksAlias.GetRef()
ObjectReference alias4 = Alias_VegAlias.GetRef()

Form Meat = alias1.GetBaseObject()
Form Baking = alias2.GetBaseObject()
Form Drinks = alias3.GetBaseObject()
Form Veg = alias4.GetBaseObject()

Actor player = Game.GetPlayer()

player.RemoveItem(Meat, 1, abSilent=true)
player.RemoveItem(Baking, 1, abSilent=true)
player.RemoveItem(Drinks, 1, abSilent=true)
player.RemoveItem(Veg, 1, abSilent=true)
player.AddItem(alias1, abSilent=true)
player.AddItem(alias2, abSilent=true)
player.AddItem(alias3, abSilent=true)
player.AddItem(alias4, abSilent=true)

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_4
Function Fragment_4()
;BEGIN CODE

Actor player = Game.GetPlayer()
Actor questGiver = Alias_QuestGiverAlias.GetActorRef()

Form Meat = Alias_MeatAlias.GetRef().GetBaseObject()
Form Baking = Alias_BakingAlias.GetRef().GetBaseObject()
Form Drinks = Alias_DrinksAlias.GetRef().GetBaseObject()
Form Veg = Alias_VegAlias.GetRef().GetBaseObject()

int count1 = MissiveShoppingMeatGoal.GetValueInt()
int count2 = MissiveShoppingBakingGoal.GetValueInt()
int count3 = MissiveShoppingDrinksGoal.GetValueInt()
int count4 = MissiveShoppingDrinksGoal.GetValueInt()

int RewardValue = (Meat.getGoldValue()  as int) * count1
	RewardValue = RewardValue +  ((Baking.getGoldValue()  as int) * count2)
	RewardValue = RewardValue +  ((Drinks.getGoldValue()  as int) * count3)
	RewardValue = RewardValue +  ((Veg.getGoldValue()  as int) * count4)


RewardValue = RewardValue + GoldReward.GetValue() as int

Game.GetPlayer().AddItem(Gold001, RewardValue)

player.RemoveItem(Meat, count1, questGiver)
player.RemoveItem(Baking, count2, questGiver)
player.RemoveItem(Drinks, count3, questGiver)
player.RemoveItem(Veg, count4, questGiver)

CompleteAllObjectives()
CompleteQuest()

SetStage(110)

;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

Function UpdateCount()

	Actor player = Game.GetPlayer()
	int oldCount1 = MissiveShoppingMeatCurrent.GetValueInt()
	int oldCount2 = MissiveShoppingBakingCurrent.GetValueInt()
	int oldCount3 = MissiveShoppingDrinksCurrent.GetValueInt()
	int oldCount4 = MissiveShoppingVegCurrent.GetValueInt()

	Form Meat = Alias_MeatAlias.GetRef().GetBaseObject()
	Form Baking = Alias_BakingAlias.GetRef().GetBaseObject()
	Form Drinks = Alias_DrinksAlias.GetRef().GetBaseObject()
	Form Veg = Alias_VegAlias.GetRef().GetBaseObject()

	int count1 = player.GetItemCount(Meat)
	int count2 = player.GetItemCount(Baking)
	int count3 = player.GetItemCount(Drinks)
	int count4 = player.GetItemCount(Veg)

	int goal1 = MissiveShoppingMeatGoal.GetValueInt()
	int goal2 = MissiveShoppingBakingGoal.GetValueInt()
	int goal3 = MissiveShoppingDrinksGoal.GetValueInt()
	int goal4 = MissiveShoppingVegGoal.GetValueInt()

	If count1 > goal1
		count1 = goal1
	EndIf
	If count2 > goal2
		count2 = goal2
	EndIf
	If count3 > goal3
		count3 = goal3
	EndIf
	If count4 > goal4
		count4 = goal4
	EndIf

	MissiveShoppingMeatCurrent.SetValueInt(count1)
	MissiveShoppingBakingCurrent.SetValueInt(count2)
	MissiveShoppingDrinksCurrent.SetValueInt(count3)
	MissiveShoppingVegCurrent.SetValueInt(count4)

	UpdateCurrentInstanceGlobal(MissiveShoppingMeatCurrent)
	UpdateCurrentInstanceGlobal(MissiveShoppingBakingCurrent)
	UpdateCurrentInstanceGlobal(MissiveShoppingDrinksCurrent)
	UpdateCurrentInstanceGlobal(MissiveShoppingVegCurrent)

	If oldCount1 != count1 || !IsObjectiveDisplayed(50)
		SetObjectiveDisplayed(50, true, true)
	EndIf
	If oldCount2 != count2 || !IsObjectiveDisplayed(51)
		SetObjectiveDisplayed(51, true, true)
	EndIf
	If oldCount3 != count3 || !IsObjectiveDisplayed(52)
		SetObjectiveDisplayed(52, true, true)
	EndIf
	If oldCount4 != count4 || !IsObjectiveDisplayed(53)
		SetObjectiveDisplayed(53, true, true)
	EndIf

	If count1 == goal1
		SetObjectiveCompleted(50)
	EndIf
	If count2 == goal2
		SetObjectiveCompleted(51)
	EndIf
	If count3 == goal3
		SetObjectiveCompleted(52)
	EndIf
	If count4 == goal4
		SetObjectiveCompleted(53)
	EndIf

	If count1 >= goal1 && count2 >= goal2 && count3 >= goal3 && count4 >= goal4 && GetStage() == 50
		SetStage(60)
	EndIf
EndFunction

GlobalVariable Property MissiveShoppingMeatCurrent Auto
GlobalVariable Property MissiveShoppingBakingCurrent Auto
GlobalVariable Property MissiveShoppingDrinksCurrent Auto
GlobalVariable Property MissiveShoppingVegCurrent Auto
GlobalVariable Property MissiveShoppingMeatGoal Auto
GlobalVariable Property MissiveShoppingBakingGoal Auto
GlobalVariable Property MissiveShoppingDrinksGoal Auto
GlobalVariable Property MissiveShoppingVegGoal Auto

GlobalVariable Property ItemTotalMax  Auto  
GlobalVariable Property ItemTotalMin  Auto  

MiscObject Property Gold001  Auto 
GlobalVariable Property GoldReward  Auto  
