Scriptname _M_QuestGatherItemDestScript Extends Quest Hidden

import _m_MissivesUtils
import utility		  

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY    

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

import PO3_SKSEFunctions

Event OnInit()
	
	keyword MissiveSettlement = Game.GetFormFromFile(0xF40, "MissivesfortheGoodGuys.esp") as keyword
	
	if !Alias_Destination

		if Alias_QuestGiver
			Location npcLoc    = Alias_QuestGiver.getRef().GetCurrentLocation()
			
			if npcLoc != None && npcLoc.HasKeyword(MissiveSettlement)
				Alias_Destination.ForceLocationTo(npcLoc)
			else	
				Location parentLoc = GetParentLocation(npcLoc)
				
				if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
					Alias_Destination.ForceLocationTo(parentLoc)
				else
					parentLoc = GetParentLocation(parentLoc)
					
					if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
						Alias_Destination.ForceLocationTo(parentLoc)
					endif	
				endif			
			endif
		endIf
	endif
endEvent

;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE
	; Debug.Trace("Set Stage 20")
	
	SetObjectiveDisplayed(20)
	DeliveryDate.SetValue((GameDaysPassed.GetValue() + Duration.GetValue()) as int)
	UpdateCurrentInstanceGlobal(DeliveryDate)


;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
	; Debug.Trace("Set Stage 110 Fail")
	FailAllObjectives()
	SetStage(110)
;END CODE
EndFunction
;END FRAGMENT


;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE

	DeliveryDate.SetValue((GameDaysPassed.GetValue() + Duration.GetValue()) as int)
	UpdateCurrentInstanceGlobal(DeliveryDate)

	SetObjectiveCompleted(20)
	SetObjectiveDisplayed(30)

	Alias_Item.TryToEnable()
	Actor player = Game.GetPlayer()

	AddReference(player, Alias_Item.Getref(), QContainer)
	
;END CODE
EndFunction
;END FRAGMENT						  

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
    ; Debug.Trace("Set Stage 110")
	CompleteAllObjectives()

	int RewardValue = Alias_Item.GetRef().GetBaseObject().getGoldValue() as int 

	RewardValue = RewardValue + GoldReward.GetValue() as int

	CompleteAllObjectives()
	
	Game.GetPlayer().RemoveItem(Alias_Item.GetRef(), 1)
	Game.GetPlayer().AddItem(Gold001, RewardValue)
	Game.GetPlayer().AddItem(Reward)
	
	SetStage(110)	
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE

	if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
	Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Board")
	elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
	Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
	;Debug.Trace("Missive Removed from Player")
	endIf

    m_Message.Setname(m_Message.GetBaseObject().GetName())
Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_15
Function Fragment_15()
;BEGIN CODE
    ; Debug.Trace("Set Stage 105")

	Alias_Item.GetRef().SetActorOwner(Alias_QuestGiver.GetActorRef().GetActorBase())

	int Bounty = GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue()

	SetBounty(Alias_QuestGiver.GetActorRef() as actor , Bounty)

	SetStage(105)
	
;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

Function TemperAdded(form akBaseItem, ObjectReference akItemReference, float CurrentTemper)


	if Alias_Item.getref() == akItemReference
		if(CurrentTemper > 1.0 )
			if IsObjectiveDisplayed(30) && getstage() < 40
			    SetStage(40)
				SetObjectiveCompleted(30)	
				SetObjectiveDisplayed(40, true, true)
			endif		
		endif	
	endif

endFunction


Function RecheckInventory()

	 if !recheckInprogress && IsObjectiveDisplayed(30) && Game.GetPlayer().GetItemCount(Alias_Item.GetRef()) > 0
	 
	    recheckInprogress = true

		Form ItemBase = Alias_Item.GetRef().GetBaseObject() as Form

		; debug.Trace ("rechecking inventory")
		
		float itemtemper = Alias_Item.Getref().GetItemHealthPercent() as float
		
		; debug.Trace (itemtemper)

		; Need to Drop & Pickup this to detect updated Tempers - So we remove it , then add it back to player's inventory to trigger "on item added"
		Actor player = Game.GetPlayer()
		
		if  itemtemper < 1.0 
			player.RemoveInventoryEventFilter(Alias_Item.Getref())

			DropReference(player, Alias_Item.Getref(), QContainer)

			player.AddInventoryEventFilter(Alias_Item.Getref())
		endif
		
		TemperAdded(ItemBase, Alias_Item.Getref(), Alias_Item.Getref().GetItemHealthPercent() as float)

		
		recheckInprogress = false
	endif
	
	If IsObjectiveDisplayed(30) && Game.GetPlayer().GetItemCount(Alias_Item.GetRef()) == 0 && Alias_Item.getref().IsDeleted()
		; Debug.Trace("Set Stage 103")
		SetStage(103)
	endif

EndFunction


Function SetBounty(Actor target, int amount) ;This function will increase the player's bounty for the specific region he is in by a specific amount 

	Game.IncrementStat("Items Stolen")
	
	Location EastmarchHoldLocation = Game.GetFormFromFile(0x01676A, "Skyrim.esm") as Location
	Location FalkreathHoldLocation = Game.GetFormFromFile(0x01676F, "Skyrim.esm") as Location
	Location HaafingarHoldLocation = Game.GetFormFromFile(0x016770, "Skyrim.esm") as Location
	Location HjaalmarchHoldLocation = Game.GetFormFromFile(0x01676E, "Skyrim.esm") as Location
	Location PaleHoldLocation = Game.GetFormFromFile(0x01676D, "Skyrim.esm") as Location
	Location ReachHoldLocation = Game.GetFormFromFile(0x016769, "Skyrim.esm") as Location
	Location RiftHoldLocation = Game.GetFormFromFile(0x01676C, "Skyrim.esm") as Location
	Location WhiterunHoldLocation = Game.GetFormFromFile(0x016772, "Skyrim.esm") as Location
	Location WinterholdHoldLocation = Game.GetFormFromFile(0x01676B, "Skyrim.esm") as Location
	Location DLC2SolstheimLocation = Game.GetFormFromFile(0x016E2A, "Dragonborn.esm") as Location

	Faction CrimeFactionEastmarch  = Game.GetFormFromFile(0x0267E3, "Skyrim.esm") as faction
	Faction CrimeFactionFalkreath  = Game.GetFormFromFile(0x028170, "Skyrim.esm") as faction
	Faction CrimeFactionHaafingar  = Game.GetFormFromFile(0x029DB0, "Skyrim.esm") as faction
	Faction CrimeFactionReach = Game.GetFormFromFile(0x02816C, "Skyrim.esm") as faction
	Faction CrimeFactionHjaalmarch = Game.GetFormFromFile(0x02816D, "Skyrim.esm") as faction
	Faction CrimeFactionPale = Game.GetFormFromFile(0x02816E, "Skyrim.esm") as faction
	Faction CrimeFactionRift = Game.GetFormFromFile(0x02816B, "Skyrim.esm") as faction
	Faction CrimeFactionWhiterun = Game.GetFormFromFile(0x0267EA, "Skyrim.esm") as faction
	Faction CrimeFactionWinterhold = Game.GetFormFromFile(0x02816F, "Skyrim.esm") as faction
	Faction CrimeFactionSolstheim = Game.GetFormFromFile(0x018279, "Dragonborn.esm") as faction
	
	Faction Currentlocation = CrimeFactionWhiterun as faction
 
	If target.IsInLocation(WhiterunHoldLocation)
		 Currentlocation = CrimeFactionWhiterun

	elseif target.IsInLocation(FalkreathHoldLocation)
		 Currentlocation = CrimeFactionFalkreath 
	elseif target.IsInLocation(EastmarchHoldLocation)
		 Currentlocation = CrimeFactionEastmarch 

	elseif target.IsInLocation(HaafingarHoldLocation)
		 Currentlocation = CrimeFactionHaafingar 

	elseif target.IsInLocation(ReachHoldLocation)
		 Currentlocation = CrimeFactionReach 

	elseif target.IsInLocation(HjaalmarchHoldLocation)
		 Currentlocation = CrimeFactionHjaalmarch 
 
	elseif target.IsInLocation(PaleHoldLocation)
		 Currentlocation = CrimeFactionPale
 
	elseif target.IsInLocation(RiftHoldLocation)
		 Currentlocation = CrimeFactionRift 
 
	elseif target.IsInLocation(WinterholdHoldLocation)
		 Currentlocation = CrimeFactionWinterhold 

	endif
	
	int OldCrimeGold = Currentlocation.GetCrimeGold() ;get bounty before we increase it

	Utility.Wait(0.10)
	Alias_Item.GetRef().SetActorOwner(target.GetActorBase())
	Currentlocation.ModCrimeGold(GoldReward.GetValue() as int + Alias_Item.GetRef().GetGoldValue())
	Game.IncrementStat("Items Stolen")

	int NewCrimeGold = Currentlocation.GetCrimeGold() ;get bounty after we increase it
	Debug.Notification((NewCrimeGold - OldCrimeGold) + " bounty from Failing Missive")

 
EndFunction

bool recheckInprogress

GlobalVariable Property GameDaysPassed  Auto  

GlobalVariable Property DeliveryDate  Auto  

GlobalVariable Property duration  Auto  

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

ObjectReference Property QContainer Auto

LeveledItem Property Reward  Auto  