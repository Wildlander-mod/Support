;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 11
Scriptname _M_QuestGatherScriptTraining Extends Quest Hidden

import PO3_SKSEFunctions

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Item
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Item Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY

Event OnInit()
    ; Try to get the GlobalVariable from Requiem.esp
     GlobalVariable tempVar = Game.GetFormFromFile(0xAD3A1B, "Requiem.esp") as GlobalVariable
    
    if tempVar != None
        REQ_Internal_Player_Is_In_Training = tempVar
    else
        Debug.Trace("Requiem.esp is NOT in the load order. Using default behavior.")
    endif
	

	keyword MissiveSettlement = Game.GetFormFromFile(0xF40, "MissivesfortheGoodGuys.esp") as keyword
	
	if !Alias_Destination

		if Alias_QuestGiver
			Location npcLoc    = Alias_QuestGiver.getRef().GetCurrentLocation()
			
			if npcLoc != None && npcLoc.HasKeyword(MissiveSettlement)
				Alias_Destination.ForceLocationTo(npcLoc)
			else	
				Location parentLoc = GetParentLocation(npcLoc)
				
				if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
					Alias_Destination.ForceLocationTo(parentLoc)
				else
					parentLoc = GetParentLocation(parentLoc)
					
					if parentLoc != None && parentLoc.HasKeyword(MissiveSettlement)
						Alias_Destination.ForceLocationTo(parentLoc)
					endif	
				endif			
			endif
		endIf
	endif

endEvent



;BEGIN FRAGMENT Fragment_5
Function Fragment_5()
;BEGIN CODE

;Debug.Trace("Missives: Update Quest Started")
;Debug.Trace(Alias_Item.GetRef().GetBaseObject().getname())
;Debug.Trace(ItemTotalMin.GetValue() as int)
;Debug.Trace(ItemTotalMax.GetValue() as int)

ItemCount.SetValue(Game.GetPlayer().GetItemCount(Alias_Item.GetRef().GetBaseObject()))

UpdateCurrentInstanceGlobal(ItemCount)
	
ItemTotal.SetValue(Utility.RandomInt(ItemTotalMin.GetValue() as int, ItemTotalMax.GetValue() as int))

if ItemTotal.GetValue() == 0
	ItemTotal.SetValue(1)
endif

;Debug.Trace("Count Assigned")

;Debug.Trace(ItemCount.GetValue() as int)
;Debug.Trace(ItemTotal.GetValue() as int)

UpdateCurrentInstanceGlobal(ItemTotal)
	
SetObjectiveDisplayed(20)

;Debug.Trace(Alias_Item.GetRef().GetBaseObject())
;Debug.Trace(ItemTotal.GetValue())

if(ItemCount.GetValue() > ItemTotal.GetValue())
SetObjectiveCompleted(20)
SetObjectiveDisplayed(40)
endIf
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
FailAllObjectives()
SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE
CompleteAllObjectives()

;Debug.Trace("Missives: Quest complete")

int RewardValue = Alias_Item.GetRef().GetBaseObject().getGoldValue() * ItemTotal.GetValue() as int * 2

;Debug.Trace(Alias_Item.GetRef().GetBaseObject().getGoldValue())
;Debug.Trace(RewardValue)

if  RewardValue == 0
	RewardValue = GoldReward.GetValue() as int
endif

Game.GetPlayer().RemoveItem(Alias_Item.GetRef().GetBaseObject(), ItemTotal.GetValue() as int)
Game.GetPlayer().AddItem(Gold001, RewardValue)

REQ_Internal_Player_Is_In_Training.SetValueInt(1)

ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByID(RewardID)
Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() 
game.AdvanceSkill(RewardName, xpRequired)

REQ_Internal_Player_Is_In_Training.SetValueInt(0)


SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE
if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef())
;Debug.Trace("Missive Removed from Player")
endIf

Stop()
;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

GlobalVariable Property ItemCount  Auto  

GlobalVariable Property ItemTotal  Auto  

GlobalVariable Property ItemTotalMax  Auto  

GlobalVariable Property ItemTotalMin  Auto  

MiscObject Property Gold001  Auto  

GlobalVariable Property GoldReward  Auto  

String Property RewardName  Auto   ; https://www.creationkit.com/index.php?title=Actor_Value_List 

int Property RewardID  Auto   ;https://www.creationkit.com/index.php?title=ActorValueInfo_Script#Actor_Value_IDs

globalvariable property REQ_Internal_Player_Is_In_Training auto

 