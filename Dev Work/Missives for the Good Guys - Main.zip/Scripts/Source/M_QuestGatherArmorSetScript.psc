;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 15
Scriptname M_QuestGatherArmorSetScript Extends Quest Hidden


;BEGIN ALIAS PROPERTY Set
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Set Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY QuestGiver
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_QuestGiver Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Player
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Player Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Hold
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Hold Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Missive
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Missive Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY boots
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_boots Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Helmet
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Helmet Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY WEAPONS
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_WEAPONS Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Curiass
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Curiass Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Gloves
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_Gloves Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY MissiveBoard
;ALIAS PROPERTY TYPE ReferenceAlias
ReferenceAlias Property Alias_MissiveBoard Auto
;END ALIAS PROPERTY

;BEGIN ALIAS PROPERTY Destination
;ALIAS PROPERTY TYPE LocationAlias
LocationAlias Property Alias_Destination Auto
;END ALIAS PROPERTY

Event OnInit()
    ; Try to get the GlobalVariable from Requiem.esp
    GlobalVariable tempVar = Game.GetFormFromFile(0xAD3A1B, "Requiem.esp") as GlobalVariable
    
    if tempVar != None
        REQ_Internal_Player_Is_In_Training = tempVar
    else
        Debug.Trace("Requiem.esp is NOT in the load order. Using default behavior.")
    endif
endEvent



;BEGIN FRAGMENT Fragment_2
Function Fragment_2()
;BEGIN CODE

	;Debug.Trace("Stage 40: Complete Quest and issue rewards")

	self.setObjectiveCompleted(40, True)

	int RewardValue = Alias_boots.GetRef().GetBaseObject().getGoldValue()  as int
        RewardValue = RewardValue +  Alias_Curiass.GetRef().GetBaseObject().getGoldValue()  as int
        RewardValue = RewardValue +  Alias_Gloves.GetRef().GetBaseObject().getGoldValue()  as int
        RewardValue = RewardValue +  Alias_Helmet.GetRef().GetBaseObject().getGoldValue()  as int
        RewardValue = RewardValue +  Alias_Weapons.GetRef().GetBaseObject().getGoldValue()  as int
			
    Game.GetPlayer().AddItem(Gold001, RewardValue)	

	game.getplayer().removeItem(Alias_boots.getRef().getBaseObject(), 1,  abSilent=True)
	game.getplayer().removeItem(Alias_Curiass.getRef().getBaseObject(), 1,  abSilent=True)
	game.getplayer().removeItem(Alias_Gloves.getRef().getBaseObject(), 1,  abSilent=True)
	game.getplayer().removeItem(Alias_Helmet.getRef().getBaseObject(), 1,  abSilent=True)
	game.getplayer().removeItem(Alias_Weapons.getRef().getBaseObject(), 1, abSilent=True)

	Int Rnd = utility.RandomInt(1, 6)
	

	REQ_Internal_Player_Is_In_Training.SetValueInt(1)
	
	if Rnd == 1
		ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByID(11)
		Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() ; From Skyrim Skill Leveling Function: xp = level ^ 1.95 * mult + offset
		
		if Skill.GetCurrentValue(game.getplayer()) < 40 
			game.AdvanceSkill("HeavyArmor", xpRequired)
		endif
    endif
    if Rnd == 2
		ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByID(12)
		Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() ; From Skyrim Skill Leveling Function: xp = level ^ 1.95 * mult + offset
		if Skill.GetCurrentValue(game.getplayer()) < 40 
		    game.AdvanceSkill("lightarmor", xpRequired)
		endif	
    Endif
    if Rnd == 3
		ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByID(9)
		Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() ; From Skyrim Skill Leveling Function: xp = level ^ 1.95 * mult + offset
		if Skill.GetCurrentValue(game.getplayer()) < 40 
		    game.AdvanceSkill("Block", xpRequired)
		endif
    Endif
	if Rnd == 4
		ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByID(6)
		Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() ; From Skyrim Skill Leveling Function: xp = level ^ 1.95 * mult + offset
		if Skill.GetCurrentValue(game.getplayer()) < 40 
		    game.AdvanceSkill("OneHanded", xpRequired)
		endif
    endif
    if Rnd == 5
		ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByID(7)
		Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() ; From Skyrim Skill Leveling Function: xp = level ^ 1.95 * mult + offset
		if Skill.GetCurrentValue(game.getplayer()) < 40 
		    game.AdvanceSkill("TwoHanded", xpRequired)
		endif
    Endif
    if Rnd == 6
		ActorValueInfo Skill = ActorValueInfo.GetActorValueInfoByID(8)
		Float xpRequired = (Math.Pow(Skill.GetCurrentValue(game.getplayer()), 1.95) * Skill.GetSkillImproveMult()) + Skill.GetSkillOffsetMult() ; From Skyrim Skill Leveling Function: xp = level ^ 1.95 * mult + offset
		if Skill.GetCurrentValue(game.getplayer()) < 40 
		    game.AdvanceSkill("Marksman", xpRequired)
		endif
    Endif
	
	
	REQ_Internal_Player_Is_In_Training.SetValueInt(0)
		 
	SetStage(110)
	
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_7
Function Fragment_7()
;BEGIN CODE
;Debug.Trace("Stage 105 code")
	FailAllObjectives()
	SetStage(110)
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_6
Function Fragment_6()
;BEGIN CODE

	UpdateCount()

;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_9
Function Fragment_9()
;BEGIN CODE
;Debug.Trace("Stage 110 Missive tidyup")

if(Alias_MissiveBoard.GetRef().GetItemCount(Alias_Missive.GetRef()) > 0)
Alias_MissiveBoard.GetRef().RemoveItem(Alias_Missive.GetRef() )
;Debug.Trace("Missive Removed from Board")
elseif(Game.GetPlayer().GetItemCount(Alias_Missive.GetRef()) > 0)
Game.GetPlayer().RemoveItem(Alias_Missive.GetRef(), abSilent=True)
;Debug.Trace("Missive Removed from Player")

endIf

Stop()
;END CODE
EndFunction
;END FRAGMENT

;BEGIN FRAGMENT Fragment_13
Function Fragment_13()

;BEGIN CODE

    ;Debug.Trace("Stage 5: Missive Setup - Select armor set and weapons")

	Int Rnd = utility.RandomInt(1, _M_ListCuirass.GetSize()) - 1

	myBoots = game.getplayer().placeAtMe(_M_Listboots.GetAt(Rnd), abInitiallyDisabled = True)
	Alias_Boots.ForceRefTo(myBoots)
	
	mychest = game.getplayer().PlaceAtMe(_M_ListCuirass.GetAt(Rnd), abInitiallyDisabled = True)
	Alias_Curiass.ForceRefTo(mychest)

	myGloves = game.getplayer().PlaceAtMe(_M_ListGauntlets.GetAt(Rnd), abInitiallyDisabled = True)
	Alias_Gloves.ForceRefTo(myGloves)

	myHelm = game.getplayer().PlaceAtMe(_M_ListHelmet.GetAt(Rnd), abInitiallyDisabled = True)
	Alias_Helmet.ForceRefTo(myHelm)

	mySet = game.getplayer().PlaceAtMe(_M_ListSet.GetAt(Rnd) , abInitiallyDisabled = True)
	Alias_Set.ForceRefTo(mySet)	
	
    Rnd = utility.RandomInt(0, _M_ListWeapon.GetSize()) - 1
	
	myWeapon = game.getplayer().PlaceAtMe(_M_ListWeapon.GetAt(Rnd), abInitiallyDisabled = True)
	
	Alias_Weapons.ForceRefTo(myWeapon)
	
	if(Alias_WEAPONS.GetRef())
		Alias_Player.AddInventoryEventFilter(Alias_WEAPONS.GetRef().GetBaseObject())
	endIf
	if(Alias_Curiass.GetRef())
		Alias_Player.AddInventoryEventFilter(Alias_Curiass.GetRef().GetBaseObject())
	endIf
	if(Alias_Gloves.GetRef())
		Alias_Player.AddInventoryEventFilter(Alias_Gloves.GetRef().GetBaseObject())
	endIf
	if(Alias_Helmet.GetRef())
		Alias_Player.AddInventoryEventFilter(Alias_Helmet.GetRef().GetBaseObject())
	endIf
	if(Alias_Boots.GetRef())
		Alias_Player.AddInventoryEventFilter(Alias_Boots.GetRef().GetBaseObject())
	endIf
	
	HasGloves.SetValueInt(99)
	HasBoots.SetValueInt(99)
	HasChest.SetValueInt(99)
	HasWeapon.SetValueInt(99)
	HasHelm.SetValueInt(99)
	
	UpdateCurrentInstanceGlobal(HasGloves)
	UpdateCurrentInstanceGlobal(HasBoots)
	UpdateCurrentInstanceGlobal(HasChest)
	UpdateCurrentInstanceGlobal(HasWeapon)
	UpdateCurrentInstanceGlobal(HasHelm)
	
;END CODE
EndFunction  
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment


Function UpdateCount()

	form myBoots1     = Alias_Boots.getRef().getBaseObject()
	form myCuirass1   = Alias_Curiass.getRef().getBaseObject()
	form myGauntlets1 = Alias_Gloves.getRef().getBaseObject()
	form myHelmet1    = Alias_Helmet.getRef().getBaseObject()
	form myWeapon1    = Alias_WEAPONS.getRef().getBaseObject()

	int ObjectivesMet = 0
	
	int oldCount1 = HasBoots.GetValueInt()
	int oldCount2 = HasChest.GetValueInt()
	int oldCount3 = HasGloves.GetValueInt()
	int oldCount4 = HasHelm.GetValueInt()
	int oldCount5 = HasWeapon.GetValueInt()
	
	int NewCount1 = game.getplayer().getItemCount(myBoots1)
	int NewCount2 = game.getplayer().getItemCount(myCuirass1)
	int newCount3 = game.getplayer().getItemCount(myGauntlets1) 
	int newCount4 = game.getplayer().getItemCount(myHelmet1) 
	int NewCount5 = game.getplayer().getItemCount(myWeapon1)
	
	
	HasBoots.SetValueInt(NewCount1)
	HasChest.SetValueInt(NewCount2)
	HasGloves.SetValueInt(newCount3)
	HasHelm.SetValueInt(newCount4)
	HasWeapon.SetValueInt(NewCount5)	

	UpdateCurrentInstanceGlobal(HasGloves)
	UpdateCurrentInstanceGlobal(HasBoots)
	UpdateCurrentInstanceGlobal(HasChest)
	UpdateCurrentInstanceGlobal(HasWeapon)
	UpdateCurrentInstanceGlobal(HasHelm)
	

	If (oldCount1 != NewCount1 && NewCount1 < 1) || !IsObjectiveDisplayed(1)
		SetObjectiveDisplayed(1, true, true)
	EndIf
	If (oldCount2 != Newcount2 && NewCount2 < 1) || !IsObjectiveDisplayed(2)
		SetObjectiveDisplayed(2, true, true)
	EndIf
	If (oldCount3 != Newcount3 && NewCount3 < 1) || !IsObjectiveDisplayed(3)
		SetObjectiveDisplayed(3, true, true)
	EndIf
	If (oldCount4 != Newcount4 && NewCount4 < 1) || !IsObjectiveDisplayed(4)
		SetObjectiveDisplayed(4, true, true)
	EndIf
	If (oldCount5 != Newcount5 && NewCount5 < 1) || !IsObjectiveDisplayed(5)
		SetObjectiveDisplayed(5, true, true)
	EndIf

	If NewCount1 > 0
		SetObjectiveCompleted(1)
		ObjectivesMet += 1
	EndIf
	If NewCount2 > 0
		SetObjectiveCompleted(2)
		ObjectivesMet += 1
	EndIf
	If NewCount3 > 0
		SetObjectiveCompleted(3)
		ObjectivesMet += 1
	EndIf
	If NewCount4 > 0
		SetObjectiveCompleted(4)
		ObjectivesMet += 1
	EndIf
	If NewCount5 > 0
		SetObjectiveCompleted(5)
		ObjectivesMet += 1
	EndIf

	If ObjectivesMet == 5 
		SetObjectiveDisplayed(40)
		HasItems.SetValue(ObjectivesMet)
		UpdateCurrentInstanceGlobal(HasItems)
	EndIf


EndFunction

formlist property _M_Listboots auto
formlist property _M_ListGauntlets auto
formlist property _M_ListCuirass auto
formlist property _M_ListHelmet auto
formlist property _M_ListWeapon auto
formlist property _M_ListSet auto

;Run-time objects
ObjectReference property myBoots  auto hidden
ObjectReference property myGloves auto hidden
ObjectReference property myHelm   auto hidden
ObjectReference property mychest  auto hidden
ObjectReference property myWeapon auto hidden
ObjectReference property mySet    auto hidden

MiscObject Property Gold001  Auto 

GlobalVariable Property HasItems  Auto 
globalvariable property REQ_Internal_Player_Is_In_Training auto

GlobalVariable Property HasBoots  Auto  
GlobalVariable Property HasGloves   Auto  
GlobalVariable Property HasChest   Auto  
GlobalVariable Property HasHelm  Auto  
GlobalVariable Property HasWeapon   Auto  
