Scriptname _M_AliasPlayerGatherSet extends ReferenceAlias  

Event OnItemAdded(Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akSourceContainer)

	If (GetOwningQuest().GetStage() == 20 && GetOwningQuest().IsObjectivedisplayed(40) == false)
		M_QuestGatherArmorSetScript SetQuest = GetOwningQuest() as M_QuestGatherArmorSetScript
		SetQuest.UpdateCount()
	EndIf
EndEvent

Event OnItemRemoved(Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akDestContainer)

	If  (GetOwningQuest().GetStage() == 20 && getOwningQuest().IsObjectiveCompleted(40) == false)
		M_QuestGatherArmorSetScript SetQuest = GetOwningQuest() as M_QuestGatherArmorSetScript
		SetQuest.UpdateCount()
	EndIf 
EndEvent
