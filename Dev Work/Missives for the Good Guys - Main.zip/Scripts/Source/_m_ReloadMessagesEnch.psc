ScriptName _m_ReloadMessagesEnch extends ReferenceAlias
 
Event OnPlayerLoadGame()

	(GetOwningQuest() as _M_QuestGatherEnchantDestScript).Maintenance()
EndEvent