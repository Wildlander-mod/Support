Scriptname _M_AliasPlayerTemperDrop extends ReferenceAlias  

ObjectReference Property QContainer Auto

Event OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer)

	if GetOwningQuest().getstage() < 40 
		if(GetOwningQuest().IsObjectiveDisplayed(30)|| GetOwningQuest().IsObjectiveDisplayed(25))
			if(akNewContainer == Game.GetPlayer() && GetOwningQuest().IsObjectiveDisplayed(25) )
					GetOwningQuest().SetObjectiveDisplayed(30, true, true)
				   (GetOwningQuest() as _M_QuestGatherItemDestScript).RecheckInventory()		   	   
			elseif(akOldContainer == Game.GetPlayer() && !akNewContainer == QContainer)	
					GetOwningQuest().SetObjectiveDisplayed(25, true, true)
					GetOwningQuest().SetObjectiveDisplayed(30, false)
			endIf
		endIf
	endif
	
	if(GetOwningQuest().IsObjectiveDisplayed(40) || GetOwningQuest().IsObjectiveDisplayed(35))
		if(akNewContainer == Game.GetPlayer() && GetOwningQuest().IsObjectiveDisplayed(35) )
				GetOwningQuest().SetObjectiveDisplayed(35, false)
				GetOwningQuest().SetObjectiveDisplayed(40, true, true)			
		elseif(akOldContainer == Game.GetPlayer() && !akNewContainer == QContainer)	
				GetOwningQuest().SetObjectiveDisplayed(35, true, true)
				GetOwningQuest().SetObjectiveDisplayed(40, false)
		endIf
	endIf
endEvent