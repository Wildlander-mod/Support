Scriptname _M_AliasPlayerCourier extends ReferenceAlias

GlobalVariable Property DeliveryDate Auto
GlobalVariable Property GameDaysPassed Auto

Event OnInit()
	RegisterForUpdateGameTime(0.1)
endEvent

Event OnUpdateGameTime()
	if(GetOwningQuest().GetStage() > 20 && GetOwningQuest().GetStage() < 100)
		if(GameDaysPassed.GetValue() > DeliveryDate.GetValue())
			;debug.trace("Deliver failed - set 103")
			GetOwningQuest().SetStage(103)
		endIf
	endIf
endEvent